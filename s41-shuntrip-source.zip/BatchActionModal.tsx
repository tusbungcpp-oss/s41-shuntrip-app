import React, { useState } from 'react';
import { 
  X, 
  Layers, 
  PowerOff, 
  Power, 
  Play, 
  Check
} from 'lucide-react';
import type { S41Device, UserProfile } from '../types';
import { executeSmsCommand } from '../lib/smsEngine';

interface BatchActionModalProps {
  selectedDevices: S41Device[];
  currentUser: UserProfile;
  onClose: () => void;
  onBatchComplete: (updatedDevices: S41Device[]) => void;
  onAddLog: (log: any) => void;
}

export const BatchActionModal: React.FC<BatchActionModalProps> = ({
  selectedDevices,
  currentUser,
  onClose,
  onBatchComplete,
  onAddLog,
}) => {
  const [actionType, setActionType] = useState<'PLNOFF' | 'PLNON'>('PLNOFF');
  const [isRunning, setIsRunning] = useState(false);
  const [currentIndex, setCurrentIndex] = useState<number>(-1);
  const [completedResults, setCompletedResults] = useState<Array<{ id: string; success: boolean; msg: string }>>([]);

  const handleStartBatch = async () => {
    if (selectedDevices.length === 0) return;

    const actionText = actionType === 'PLNOFF' ? 'PEMUTUSAN MASAL (PLNOFF)' : 'PENYAMBUNGAN MASAL (PLNON)';
    if (!confirm(`Konfirmasi: Anda akan menjalankan ${actionText} untuk ${selectedDevices.length} pelanggan terpilih. Lanjutkan?`)) {
      return;
    }

    setIsRunning(true);
    setCompletedResults([]);

    const updatedList: S41Device[] = [...selectedDevices];

    for (let i = 0; i < selectedDevices.length; i++) {
      setCurrentIndex(i);
      const dev = selectedDevices[i];

      try {
        const res = await executeSmsCommand(dev, actionType, 'direct');
        
        // Record log
        onAddLog({
          id: 'batch-log-' + Date.now() + '-' + i,
          device_id: dev.id,
          idpel: dev.idpel,
          nama_pelanggan: dev.nama_pelanggan,
          command: actionType,
          sender_name: currentUser.nama + ' (Batch)',
          sender_role: currentUser.role,
          status: res.success ? 'SUCCESS' : 'FAILED',
          response_message: `[Kolektif] ` + (res.response || res.message),
          timestamp: new Date().toISOString()
        });

        updatedList[i] = {
          ...dev,
          status_relay: actionType === 'PLNOFF' ? 'OFF' : 'ON',
          updated_at: new Date().toISOString()
        };

        setCompletedResults((prev) => [
          ...prev,
          { id: dev.id, success: true, msg: res.response || 'Berhasil' }
        ]);

      } catch (err: any) {
        setCompletedResults((prev) => [
          ...prev,
          { id: dev.id, success: false, msg: err.message || 'Gagal' }
        ]);
      }

      // Small delay between batch SMS to prevent network congestion
      await new Promise(r => setTimeout(r, 600));
    }

    setIsRunning(false);
    setCurrentIndex(-1);
    onBatchComplete(updatedList);
  };

  const progressPercent = selectedDevices.length > 0 
    ? Math.round((completedResults.length / selectedDevices.length) * 100) 
    : 0;

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-2xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#003664] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
              <Layers className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">EKSEKUSI KOLEKTIF (BATCH)</h2>
              <p className="text-[10px] text-blue-200">
                {selectedDevices.length} Pelanggan S41 Dipilih
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            disabled={isRunning}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white disabled:opacity-30"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">
          
          {/* Action Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              PILIH PERINTAH KOLEKTIF:
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={isRunning}
                onClick={() => setActionType('PLNOFF')}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  actionType === 'PLNOFF'
                    ? 'border-red-600 bg-red-50 text-red-950 font-bold'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <PowerOff className="w-4 h-4 text-red-600" />
                  <span>PEMUTUSAN</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-mono">Kirim PLNOFF massal</p>
              </button>

              <button
                type="button"
                disabled={isRunning}
                onClick={() => setActionType('PLNON')}
                className={`p-3 rounded-xl border-2 text-left transition-all ${
                  actionType === 'PLNON'
                    ? 'border-emerald-600 bg-emerald-50 text-emerald-950 font-bold'
                    : 'border-slate-200 hover:border-slate-300 text-slate-700'
                }`}
              >
                <div className="flex items-center gap-1.5 text-xs">
                  <Power className="w-4 h-4 text-emerald-600" />
                  <span>PENYAMBUNGAN</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-mono">Kirim PLNON massal</p>
              </button>
            </div>
          </div>

          {/* Progress Bar when running */}
          {isRunning && (
            <div className="space-y-1.5 bg-slate-50 p-3 rounded-xl border border-slate-200">
              <div className="flex justify-between text-xs font-bold text-slate-700">
                <span>Menginjek SMS ({completedResults.length}/{selectedDevices.length})...</span>
                <span>{progressPercent}%</span>
              </div>
              <div className="w-full h-2.5 bg-slate-200 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-blue-600 transition-all duration-300"
                  style={{ width: `${progressPercent}%` }}
                ></div>
              </div>
            </div>
          )}

          {/* Selected Devices List */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-2">
              DAFTAR PELANGGAN ANTRIAN:
            </label>
            <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
              {selectedDevices.map((dev, idx) => {
                const isCurrent = isRunning && currentIndex === idx;
                const result = completedResults.find(r => r.id === dev.id);

                return (
                  <div
                    key={dev.id}
                    className={`p-2.5 rounded-xl border text-xs flex items-center justify-between transition-all ${
                      isCurrent
                        ? 'border-blue-500 bg-blue-50/70 shadow-sm'
                        : result?.success
                        ? 'border-emerald-200 bg-emerald-50/40 text-emerald-900'
                        : 'border-slate-200 bg-white'
                    }`}
                  >
                    <div className="truncate pr-2">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-slate-900 truncate">{dev.nama_pelanggan}</span>
                        <span className="text-[10px] text-slate-500 font-mono">({dev.idpel})</span>
                      </div>
                      <p className="text-[10px] text-slate-500 font-mono">{dev.nomor_sim}</p>
                    </div>

                    <div className="shrink-0">
                      {isCurrent && (
                        <span className="text-[10px] font-bold text-blue-600 animate-pulse">
                          Mengirim...
                        </span>
                      )}
                      {result?.success && (
                        <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center">
                          <Check className="w-3.5 h-3.5" />
                        </span>
                      )}
                      {!result && !isCurrent && (
                        <span className="text-[10px] text-slate-400 font-medium">Antre</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 shrink-0">
          {!isRunning && completedResults.length === selectedDevices.length && selectedDevices.length > 0 ? (
            <button
              onClick={onClose}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md"
            >
              SELESAI & KEMBALI
            </button>
          ) : (
            <button
              disabled={isRunning || selectedDevices.length === 0}
              onClick={handleStartBatch}
              className={`w-full py-3 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg transition-all ${
                actionType === 'PLNOFF'
                  ? 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/20'
                  : 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-emerald-600/20'
              } disabled:opacity-50`}
            >
              <Play className="w-4 h-4 fill-white" />
              <span>
                MULAI EKSEKUSI {actionType === 'PLNOFF' ? 'PEMUTUSAN' : 'PENYAMBUNGAN'} ({selectedDevices.length})
              </span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
