import { createClient } from '@supabase/supabase-js';
import type { S41Device, CommandLog } from '../types';

// Read config from localStorage or env
const getSupabaseConfig = () => {
  const localUrl = localStorage.getItem('s41_supabase_url');
  const localKey = localStorage.getItem('s41_supabase_key');
  return {
    url: localUrl || import.meta.env.VITE_SUPABASE_URL || 'https://lkpzvlrukbreklhbcywx.supabase.co',
    key: localKey || import.meta.env.VITE_SUPABASE_ANON_KEY || 'sb_publishable_JkVrmLdJJm7v7qbGTQ98ww_ZfoflHbg'
  };
};

export const hasSupabaseConfig = () => {
  const config = getSupabaseConfig();
  return Boolean(config.url && config.key);
};

export const getSupabaseClient = () => {
  const config = getSupabaseConfig();
  if (config.url && config.key) {
    return createClient(config.url, config.key);
  }
  return null;
};

// SQL Schema for the user to run in Supabase SQL Editor
export const SUPABASE_SQL_SCHEMA = `-- ==========================================
-- SKEMA DATABASE S41 SHUNTRIP (PLN DANANTARA)
-- Jalankan skrip ini di SQL Editor Supabase Anda
-- Dashboard: https://supabase.com/dashboard/project/lkpzvlrukbreklhbcywx/sql/new
-- ==========================================

-- 1. Tabel Unit Kerja PLN
create table if not exists pln_units (
  id uuid primary key default gen_random_uuid(),
  uid_name text not null,       -- misal: UID Sulselrabar
  up3_name text not null,       -- misal: UP3 Watampone
  ulp_name text not null,       -- misal: ULP Patangkai
  created_at timestamp with time zone default now()
);

-- 2. Tabel Perangkat S41 & Pelanggan
create table if not exists s41_devices (
  id text primary key,
  idpel varchar(20) unique not null,
  nama_pelanggan text not null,
  tarif_daya varchar(20) default 'R1/900 VA',
  nomor_meter varchar(20) not null,
  nomor_sim varchar(25) not null,   -- format +628...
  masa_aktif_sim date not null,
  tiang_jtr varchar(50),
  alamat text,
  status_relay text default 'ON' check (status_relay in ('ON', 'OFF', 'UNKNOWN')),
  status_tunggakan text default 'LUNAS' check (status_tunggakan in ('LUNAS', 'MENUNGGAK')),
  signal_dbm integer default -68,
  uptime text default '1m 50d',
  unit_ulp text default 'ULP Patangkai',
  unit_up3 text default 'UP3 Watampone',
  unit_uid text default 'UID Sulselrabar',
  foto_instalasi text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- 3. Tabel Riwayat Mutasi / Relokasi Alat
create table if not exists s41_relocations (
  id uuid primary key default gen_random_uuid(),
  device_id text,
  nomor_sim text not null,
  idpel_asal varchar(20) not null,
  nama_asal text not null,
  idpel_tujuan varchar(20) not null,
  nama_tujuan text not null,
  alamat_tujuan text,
  tiang_tujuan text,
  alasan text,
  ganti_sim boolean default false,
  nomor_sim_baru text,
  relocated_by text not null,
  timestamp timestamp with time zone default now()
);

-- 4. Tabel Log Eksekusi Perintah SMS (Audit Trail)
create table if not exists s41_command_logs (
  id uuid primary key default gen_random_uuid(),
  idpel varchar(20) not null,
  nama_pelanggan text not null,
  command text not null,
  detail_arg text,
  sender_name text not null,
  sender_role text not null check (sender_role in ('admin', 'kordinator')),
  status text not null check (status in ('SENT', 'SUCCESS', 'FAILED')),
  response_message text,
  timestamp timestamp with time zone default now()
);

-- 5. Tabel Pengguna & Autentikasi Petugas S41
create table if not exists pln_users (
  id uuid primary key default gen_random_uuid(),
  nip varchar(50) unique not null,
  nama text not null,
  password text not null default 'pln123',
  role text not null check (role in ('admin', 'kordinator')),
  unit_name text not null,
  no_hp varchar(25) not null,
  is_active boolean default true,
  created_at timestamp with time zone default now()
);

-- 6. Kebijakan Keamanan (Row Level Security / RLS)
alter table pln_units enable row level security;
alter table s41_devices enable row level security;
alter table s41_relocations enable row level security;
alter table s41_command_logs enable row level security;
alter table pln_users enable row level security;

create policy "Public full access pln_units" on pln_units for all using (true) with check (true);
create policy "Public full access s41_devices" on s41_devices for all using (true) with check (true);
create policy "Public full access s41_relocations" on s41_relocations for all using (true) with check (true);
create policy "Public full access s41_command_logs" on s41_command_logs for all using (true) with check (true);
create policy "Public full access pln_users" on pln_users for all using (true) with check (true);

-- 7. Data Awal Pengguna / Petugas
insert into pln_users (nip, nama, password, role, unit_name, no_hp)
values
  ('9418658ZY', 'Ir. Ahmad Afandi, S.T., M.M. IPP', 'pln123', 'admin', 'UP3 Watampone - Kantor Induk', '+6281575464944'),
  ('9620112ZY', 'Ruslan (Kordinator Lapangan)', 'pln123', 'kordinator', 'ULP Patangkai - Lapangan', '+6281234567890')
on conflict (nip) do nothing;

-- 8. Data Awal Contoh S41 (Demo Data dari Dokumen Inovasi)
insert into s41_devices (id, idpel, nama_pelanggan, tarif_daya, nomor_meter, nomor_sim, masa_aktif_sim, tiang_jtr, alamat, status_relay, status_tunggakan, signal_dbm, uptime, unit_ulp, unit_up3, unit_uid)
values 
  ('dev-1', '541200389123', 'H. Demmuh', 'R1/1300 VA', '12672657', '+6285151218524', '2026-12-31', 'TR-PTK-042', 'Lentu, Kec. Bontoramba, Jeneponto', 'ON', 'MENUNGGAK', -68, '1m 50d', 'ULP Patangkai', 'UP3 Watampone', 'UID Sulselrabar'),
  ('dev-2', '541200492811', 'M. Yunus', 'R1/900 VA', '32912400', '+6281665785645', '2026-11-28', 'TR-PTK-015', 'Jl. Poros Bone - Makassar Km 14', 'ON', 'MENUNGGAK', -72, '12d 4h', 'ULP Patangkai', 'UP3 Watampone', 'UID Sulselrabar'),
  ('dev-3', '541200118274', 'Agus Salim', 'R1/2200 VA', '67351099', '+6281244556677', '2026-12-15', 'TR-PTK-088', 'Desa Mallari, Awangpone', 'OFF', 'MENUNGGAK', -65, '45d 8h', 'ULP Patangkai', 'UP3 Watampone', 'UID Sulselrabar'),
  ('dev-4', '541200783109', 'Abd. Rahman', 'R1/900 VA', '44102931', '+6281355667788', '2027-01-20', 'TR-PTK-102', 'Kel. Biru, Tanete Riattang', 'ON', 'LUNAS', -60, '3m 12d', 'ULP Patangkai', 'UP3 Watampone', 'UID Sulselrabar'),
  ('dev-5', '541200889210', 'Turni / Sennang', 'R1/450 VA', '11829034', '+6285299887766', '2026-11-20', 'TR-PTK-009', 'Desa Mario, Mare', 'OFF', 'MENUNGGAK', -80, '5d 1h', 'ULP Patangkai', 'UP3 Watampone', 'UID Sulselrabar')
on conflict (idpel) do nothing;
`;

// Default seed data for offline / initial preview
export const INITIAL_DEVICES: S41Device[] = [
  {
    id: 'dev-1',
    idpel: '541200389123',
    nama_pelanggan: 'H. Demmuh',
    tarif_daya: 'R1/1300 VA',
    nomor_meter: '12672657',
    nomor_sim: '+6285151218524',
    masa_aktif_sim: '2026-12-31',
    tiang_jtr: 'TR-PTK-042',
    alamat: 'Lentu, Kec. Bontoramba, Jeneponto',
    status_relay: 'ON',
    status_tunggakan: 'MENUNGGAK',
    signal_dbm: -68,
    uptime: '1m 50d',
    unit_ulp: 'ULP Patangkai',
    unit_up3: 'UP3 Watampone',
    unit_uid: 'UID Sulselrabar',
    created_at: '2026-06-22T10:55:00Z',
    updated_at: '2026-11-12T10:00:00Z'
  },
  {
    id: 'dev-2',
    idpel: '541200492811',
    nama_pelanggan: 'M. Yunus',
    tarif_daya: 'R1/900 VA',
    nomor_meter: '32912400',
    nomor_sim: '+6281665785645',
    masa_aktif_sim: '2026-11-28',
    tiang_jtr: 'TR-PTK-015',
    alamat: 'Jl. Poros Bone - Makassar Km 14',
    status_relay: 'ON',
    status_tunggakan: 'MENUNGGAK',
    signal_dbm: -72,
    uptime: '12d 4h',
    unit_ulp: 'ULP Patangkai',
    unit_up3: 'UP3 Watampone',
    unit_uid: 'UID Sulselrabar',
    created_at: '2026-08-10T08:30:00Z',
    updated_at: '2026-11-12T11:20:00Z'
  },
  {
    id: 'dev-3',
    idpel: '541200118274',
    nama_pelanggan: 'Agus Salim',
    tarif_daya: 'R1/2200 VA',
    nomor_meter: '67351099',
    nomor_sim: '+6281244556677',
    masa_aktif_sim: '2026-12-15',
    tiang_jtr: 'TR-PTK-088',
    alamat: 'Desa Mallari, Awangpone',
    status_relay: 'OFF',
    status_tunggakan: 'MENUNGGAK',
    signal_dbm: -65,
    uptime: '45d 8h',
    unit_ulp: 'ULP Patangkai',
    unit_up3: 'UP3 Watampone',
    unit_uid: 'UID Sulselrabar',
    created_at: '2026-07-05T14:10:00Z',
    updated_at: '2026-11-11T09:15:00Z'
  },
  {
    id: 'dev-4',
    idpel: '541200783109',
    nama_pelanggan: 'Abd. Rahman',
    tarif_daya: 'R1/900 VA',
    nomor_meter: '44102931',
    nomor_sim: '+6281355667788',
    masa_aktif_sim: '2027-01-20',
    tiang_jtr: 'TR-PTK-102',
    alamat: 'Kel. Biru, Tanete Riattang',
    status_relay: 'ON',
    status_tunggakan: 'LUNAS',
    signal_dbm: -60,
    uptime: '3m 12d',
    unit_ulp: 'ULP Patangkai',
    unit_up3: 'UP3 Watampone',
    unit_uid: 'UID Sulselrabar',
    created_at: '2026-05-18T11:45:00Z',
    updated_at: '2026-11-10T16:00:00Z'
  },
  {
    id: 'dev-5',
    idpel: '541200889210',
    nama_pelanggan: 'Turni / Sennang',
    tarif_daya: 'R1/450 VA',
    nomor_meter: '11829034',
    nomor_sim: '+6285299887766',
    masa_aktif_sim: '2026-11-20',
    tiang_jtr: 'TR-PTK-009',
    alamat: 'Desa Mario, Mare',
    status_relay: 'OFF',
    status_tunggakan: 'MENUNGGAK',
    signal_dbm: -80,
    uptime: '5d 1h',
    unit_ulp: 'ULP Patangkai',
    unit_up3: 'UP3 Watampone',
    unit_uid: 'UID Sulselrabar',
    created_at: '2026-09-01T13:20:00Z',
    updated_at: '2026-11-12T14:40:00Z'
  }
];

export const INITIAL_LOGS: CommandLog[] = [
  {
    id: 'log-1',
    device_id: 'dev-1',
    idpel: '541200389123',
    nama_pelanggan: 'H. Demmuh',
    command: 'PLNSTATUS',
    sender_name: 'Ir. Ahmad Afandi',
    sender_role: 'admin',
    status: 'SUCCESS',
    response_message: '=== STATUS ===\nUptime: 1m 50d\nRelay: ON (NC)\nPC817: AKTIF (RELAY NC)\nValidasi: KONSISTEN\nSinyal: -68 dBm',
    timestamp: '2026-11-12T10:51:00Z'
  },
  {
    id: 'log-2',
    device_id: 'dev-3',
    idpel: '541200118274',
    nama_pelanggan: 'Agus Salim',
    command: 'PLNOFF',
    sender_name: 'Ruslan (Kordinator Lapangan)',
    sender_role: 'kordinator',
    status: 'SUCCESS',
    response_message: 'LISTRIK PADAM - BERHASIL (RELAY NO)',
    timestamp: '2026-11-11T09:15:00Z'
  }
];
