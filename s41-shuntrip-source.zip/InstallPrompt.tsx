import React, { useState, useEffect } from 'react';
import { Download, X, Share2, PlusSquare, Smartphone } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export const InstallPrompt: React.FC = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isIOS, setIsIOS] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Check if already in standalone mode (already installed & opened as PWA)
    const isInStandalone = 
      window.matchMedia('(display-mode: standalone)').matches || 
      (window.navigator as any).standalone === true;

    if (isInStandalone) {
      setIsStandalone(true);
      return;
    }

    // Detect iOS
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isIosDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsIOS(isIosDevice);

    // Listen for Android beforeinstallprompt
    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;

    deferredPrompt.prompt();
    const choice = await deferredPrompt.userChoice;
    if (choice.outcome === 'accepted') {
      console.log('User installed S41 PWA');
    }
    setDeferredPrompt(null);
  };

  // If already installed or dismissed, don't show
  if (isStandalone || dismissed) {
    return null;
  }

  // Android / Chrome Install Banner
  if (deferredPrompt) {
    return (
      <div className="fixed bottom-3 left-4 right-4 z-40 max-w-md mx-auto">
        <div className="bg-slate-900/95 backdrop-blur-md text-white p-3.5 rounded-2xl shadow-2xl border border-blue-500/30 flex items-center justify-between gap-3 animate-in slide-in-from-bottom duration-300">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-blue-600 p-1.5 flex items-center justify-center shrink-0 shadow-md">
              <img src="/logo-s41.svg" alt="S41" className="w-full h-full object-contain" />
            </div>
            <div>
              <h4 className="font-black text-xs tracking-tight text-white flex items-center gap-1">
                <span>PASANG DI HP</span>
                <span className="bg-[#FED400] text-[#003664] text-[9px] font-black px-1 rounded">PWA</span>
              </h4>
              <p className="text-[10px] text-slate-300 line-clamp-1">
                Buka lebih cepat & layar penuh tanpa browser
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={handleInstallClick}
              className="px-3 py-1.5 bg-[#FED400] hover:bg-yellow-400 text-[#003664] font-black text-xs rounded-xl shadow-md active:scale-95 transition-all flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Instal</span>
            </button>
            <button
              onClick={() => setDismissed(true)}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    );
  }

  // iOS Safari Install Tooltip
  if (isIOS) {
    return (
      <div className="fixed bottom-3 left-4 right-4 z-40 max-w-md mx-auto">
        <div className="bg-slate-900/95 backdrop-blur-md text-white p-3 rounded-2xl shadow-2xl border border-slate-700 flex items-start justify-between gap-2 text-xs">
          <div className="flex items-start gap-2">
            <Smartphone className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
            <div className="text-[11px] text-slate-200">
              <strong className="text-white block">Pasang di iPhone / iPad:</strong>
              Ketuk tombol <strong>Bagikan (Share)</strong> <Share2 className="w-3 h-3 inline text-blue-400" /> di bawah, lalu pilih <strong>"Tambahkan ke Layar Utama"</strong> <PlusSquare className="w-3 h-3 inline text-emerald-400" />.
            </div>
          </div>
          <button
            onClick={() => setDismissed(true)}
            className="text-slate-400 hover:text-white p-1"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    );
  }

  return null;
};
