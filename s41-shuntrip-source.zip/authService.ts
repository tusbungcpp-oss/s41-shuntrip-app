import { getSupabaseClient } from './supabase';
import type { UserProfile, UserRole } from '../types';

export interface DbUser {
  id: string;
  nip: string;
  nama: string;
  password?: string;
  role: UserRole;
  unit_name: string;
  no_hp: string;
  is_active: boolean;
  created_at?: string;
}

export const authenticateUser = async (
  nip: string,
  pass: string
): Promise<{ success: boolean; user?: UserProfile; message?: string }> => {
  const supabase = getSupabaseClient();
  if (!supabase) {
    return { success: false, message: 'Koneksi Supabase belum siap.' };
  }

  try {
    const { data, error } = await supabase
      .from('pln_users')
      .select('*')
      .eq('nip', nip.trim())
      .single();

    if (error || !data) {
      return { 
        success: false, 
        message: 'NIP Petugas tidak terdaftar di sistem PLN.' 
      };
    }

    if (!data.is_active) {
      return { 
        success: false, 
        message: 'Akun petugas ini sedang dinonaktifkan oleh Administrator.' 
      };
    }

    if (data.password !== pass.trim()) {
      return { 
        success: false, 
        message: 'Kata sandi / PIN yang Anda masukkan salah.' 
      };
    }

    const userProfile: UserProfile = {
      id: data.id,
      nip: data.nip,
      nama: data.nama,
      role: data.role as UserRole,
      unit_name: data.unit_name,
      phone: data.no_hp
    };

    return { success: true, user: userProfile };
  } catch (err: any) {
    return { success: false, message: 'Gagal autentikasi: ' + err.message };
  }
};

export const fetchAllUsers = async (): Promise<DbUser[]> => {
  const supabase = getSupabaseClient();
  if (!supabase) return [];

  try {
    const { data, error } = await supabase
      .from('pln_users')
      .select('id, nip, nama, role, unit_name, no_hp, is_active, created_at')
      .order('created_at', { ascending: false });

    if (error || !data) return [];
    return data as DbUser[];
  } catch {
    return [];
  }
};

export const createNewUser = async (user: Omit<DbUser, 'id'>): Promise<{ success: boolean; message?: string }> => {
  const supabase = getSupabaseClient();
  if (!supabase) return { success: false, message: 'Supabase tidak terhubung.' };

  try {
    const { error } = await supabase.from('pln_users').insert({
      nip: user.nip.trim(),
      nama: user.nama.trim(),
      password: user.password?.trim() || 'pln123',
      role: user.role,
      unit_name: user.unit_name.trim(),
      no_hp: user.no_hp.trim(),
      is_active: true
    });

    if (error) {
      return { success: false, message: error.message };
    }

    return { success: true };
  } catch (e: any) {
    return { success: false, message: e.message };
  }
};

export const toggleUserStatus = async (id: string, currentStatus: boolean): Promise<boolean> => {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  try {
    const { error } = await supabase
      .from('pln_users')
      .update({ is_active: !currentStatus })
      .eq('id', id);

    return !error;
  } catch {
    return false;
  }
};
