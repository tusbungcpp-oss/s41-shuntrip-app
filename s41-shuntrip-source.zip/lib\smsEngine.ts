import { Capacitor, registerPlugin } from '@capacitor/core';
import type { DeviceStatus, S41Device } from '../types';

interface DirectSmsPluginInterface {
  sendSms(options: { phoneNumber: string; message: string }): Promise<{ success: boolean; response: string }>;
}

const DirectSms = registerPlugin<DirectSmsPluginInterface>('DirectSmsPlugin');

export interface SendSmsResult {
  success: boolean;
  message: string;
  response?: string;
  newRelayStatus?: DeviceStatus;
  newSignalDbm?: number;
}

// Clean and ensure +62 format according to Slide 9 rule
export const formatIndonesianPhone = (phone: string): string => {
  let cleaned = phone.replace(/[^\d+]/g, '');
  if (cleaned.startsWith('08')) {
    cleaned = '+62' + cleaned.slice(1);
  } else if (cleaned.startsWith('62')) {
    cleaned = '+' + cleaned;
  } else if (!cleaned.startsWith('+62')) {
    cleaned = '+62' + cleaned.replace(/^\+?/, '');
  }
  return cleaned;
};

// Check if running in native Android container
export const isNativeAndroid = (): boolean => {
  return Capacitor.isNativePlatform() && Capacitor.getPlatform() === 'android';
};

// Direct SMS Injection & Processing
export const executeSmsCommand = async (
  device: S41Device,
  command: string,
  mode: 'direct' | 'native_app' = 'direct'
): Promise<SendSmsResult> => {
  const targetNumber = formatIndonesianPhone(device.nomor_sim);

  // If user requested standard native messaging app intent
  if (mode === 'native_app' && typeof window !== 'undefined') {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const separator = isIOS ? '&' : '?';
    const uri = `sms:${targetNumber}${separator}body=${encodeURIComponent(command)}`;
    window.open(uri, '_self');
    return {
      success: true,
      message: `Membuka aplikasi SMS untuk perintah ${command}`,
    };
  }

  // If in native Android capacitor container with SMS Plugin
  if (isNativeAndroid()) {
    try {
      const nativeRes = await DirectSms.sendSms({
        phoneNumber: targetNumber,
        message: command
      });
      return {
        success: true,
        message: `SMS ${command} berhasil diinjek langsung ke ${targetNumber}`,
        response: nativeRes.response || 'SMS terkirim melalui latar belakang sistem Android'
      };
    } catch (e: any) {
      console.warn('Native SMS bridge error:', e);
      // fallback to native SMS app if permission is missing
      const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
      const separator = isIOS ? '&' : '?';
      window.open(`sms:${targetNumber}${separator}body=${encodeURIComponent(command)}`, '_self');
      return {
        success: true,
        message: `Dialihkan ke SMS HP karena izin sistem Android belum aktif: ${e.message || e}`
      };
    }
  }

  // High-fidelity Realistic Simulation / Web Preview Engine
  // Simulates delay of GSM tower transmission (800ms)
  await new Promise((res) => setTimeout(res, 800));

  let response = '';
  let newRelayStatus: DeviceStatus | undefined = undefined;
  let newSignalDbm = device.signal_dbm || -68;

  if (command === 'PLNON') {
    response = 'LISTRIK MENYALA - BERHASIL (RELAY NC)';
    newRelayStatus = 'ON';
  } else if (command === 'PLNOFF') {
    response = 'LISTRIK PADAM - BERHASIL (RELAY NO)';
    newRelayStatus = 'OFF';
  } else if (command === 'PLNSTATUS') {
    const relayText = device.status_relay === 'ON' ? 'ON (NC)' : 'OFF (NO)';
    const pc817Text = device.status_relay === 'ON' ? 'AKTIF (RELAY NC)' : 'AKTIF (RELAY NO)';
    newSignalDbm = -65 + Math.floor(Math.random() * 8) - 4; // fluctuates slightly around -65 dBm
    response = `=== STATUS ===\nUptime: ${device.uptime || '1m 50d'}\nRelay: ${relayText}\nPC817: ${pc817Text}\nValidasi: KONSISTEN\nSinyal: ${newSignalDbm} dBm`;
    newRelayStatus = device.status_relay;
  } else if (command === 'PLNRESET') {
    response = 'DEVICE REBOOTING... OK (SEMUA MODUL KEMBALI STANDBY)';
  } else if (command.startsWith('SETADMIN:')) {
    const adminNum = command.replace('SETADMIN:', '');
    response = `SET ADMIN BERHASIL: ${adminNum} TELAH DITAMBAHKAN SEBAGAI ADMIN RESMI`;
  } else if (command.startsWith('DELADMIN:')) {
    const adminNum = command.replace('DELADMIN:', '');
    response = `DEL ADMIN BERHASIL: ${adminNum} TELAH DIHAPUS DARI DAFTAR ADMIN`;
  } else if (command === 'RESETADMIN') {
    response = 'RESET ALL ADMIN BERHASIL - SEMUA NOMOR ADMIN TELAH DIKOSONGKAN';
  } else if (command === 'LISTADMIN') {
    response = `=== DAFTAR ADMIN RESMI S41 ===\n1. +6281575464944 (Super Admin)\n2. +6281665785645 (Kordinator Lapangan)\nTotal: 2 Admin Aktif`;
  } else {
    response = `PERINTAH DITERIMA: ${command}`;
  }

  return {
    success: true,
    message: `Injeksi SMS "${command}" ke ${targetNumber} Berhasil!`,
    response,
    newRelayStatus,
    newSignalDbm
  };
};
