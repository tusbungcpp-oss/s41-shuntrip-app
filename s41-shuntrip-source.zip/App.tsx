import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Power, 
  PowerOff, 
  Smartphone, 
  MapPin, 
  Zap, 
  Layers, 
  Plus, 
  ChevronRight, 
  CheckSquare, 
  Square,
  Database,
  CheckCircle2
} from 'lucide-react';
import type { S41Device, UserProfile, CommandLog, RelocationRecord } from './types';
import { INITIAL_DEVICES, INITIAL_LOGS, hasSupabaseConfig } from './lib/supabase';
import { 
  fetchDevices, 
  fetchLogs, 
  upsertDeviceInSupabase, 
  saveLogToSupabase, 
  saveRelocationToSupabase 
} from './lib/supabaseService';
import { executeSmsCommand } from './lib/smsEngine';

// Components
import { Header } from './components/Header';
import { LoginModal } from './components/LoginModal';
import { DeviceDetailModal } from './components/DeviceDetailModal';
import { BatchActionModal } from './components/BatchActionModal';
import { RelocationModal } from './components/RelocationModal';
import { PocketBookModal } from './components/PocketBookModal';
import { LogAuditModal } from './components/LogAuditModal';
import { SupabaseConfigModal } from './components/SupabaseConfigModal';
import { AddDeviceModal } from './components/AddDeviceModal';
import { UserManagementModal } from './components/UserManagementModal';
import { InstallPrompt } from './components/InstallPrompt';

export function App() {
  // Auth state
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(() => {
    const saved = localStorage.getItem('s41_current_user');
    return saved ? JSON.parse(saved) : null;
  });

  // Devices & Logs state (with LocalStorage persistence)
  const [devices, setDevices] = useState<S41Device[]>(() => {
    const saved = localStorage.getItem('s41_devices');
    return saved ? JSON.parse(saved) : INITIAL_DEVICES;
  });

  const [logs, setLogs] = useState<CommandLog[]>(() => {
    const saved = localStorage.getItem('s41_logs');
    return saved ? JSON.parse(saved) : INITIAL_LOGS;
  });

  const [relocations, setRelocations] = useState<RelocationRecord[]>(() => {
    const saved = localStorage.getItem('s41_relocations');
    return saved ? JSON.parse(saved) : [];
  });

  const [isCloudSynced, setIsCloudSynced] = useState(false);
  const [cloudNotice, setCloudNotice] = useState<string | null>(null);

  // Load from Supabase on mount
  useEffect(() => {
    fetchDevices().then(({ data, isFromSupabase, error }) => {
      if (isFromSupabase && data.length > 0) {
        setDevices(data);
        setIsCloudSynced(true);
        setCloudNotice(null);
      } else if (error) {
        setCloudNotice('Tabel Supabase belum dibuat. Klik di sini untuk melihat & salin skrip SQL.');
      }
    });

    fetchLogs().then(({ data, isFromSupabase }) => {
      if (isFromSupabase && data.length > 0) {
        setLogs(data);
      }
    });
  }, []);

  // Sync to localStorage
  useEffect(() => {
    localStorage.setItem('s41_devices', JSON.stringify(devices));
  }, [devices]);

  useEffect(() => {
    localStorage.setItem('s41_logs', JSON.stringify(logs));
  }, [logs]);

  useEffect(() => {
    localStorage.setItem('s41_relocations', JSON.stringify(relocations));
  }, [relocations]);

  // Filtering & Search
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'MENUNGGAK' | 'OFF' | 'ON'>('ALL');

  // Modals state
  const [selectedDevice, setSelectedDevice] = useState<S41Device | null>(null);
  const [relocatingDevice, setRelocatingDevice] = useState<S41Device | null>(null);
  const [isBatchOpen, setIsBatchOpen] = useState(false);
  const [isPocketBookOpen, setIsPocketBookOpen] = useState(false);
  const [isLogsOpen, setIsLogsOpen] = useState(false);
  const [isConfigOpen, setIsConfigOpen] = useState(false);
  const [isAddDeviceOpen, setIsAddDeviceOpen] = useState(false);
  const [isUserMgmtOpen, setIsUserMgmtOpen] = useState(false);

  // Batch selection state
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Login handler
  const handleLogin = (profile: UserProfile) => {
    setCurrentUser(profile);
    localStorage.setItem('s41_current_user', JSON.stringify(profile));
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('s41_current_user');
  };

  // Add Log
  const handleAddLog = (newLog: CommandLog) => {
    setLogs((prev) => [newLog, ...prev]);
    saveLogToSupabase(newLog);
  };

  // Update Device
  const handleUpdateDevice = (updated: S41Device) => {
    setDevices((prev) => prev.map((d) => (d.id === updated.id ? updated : d)));
    if (selectedDevice?.id === updated.id) {
      setSelectedDevice(updated);
    }
    upsertDeviceInSupabase(updated);
  };

  // Add Device
  const handleAddDevice = (newDev: S41Device) => {
    setDevices((prev) => [newDev, ...prev]);
    upsertDeviceInSupabase(newDev);
    handleAddLog({
      id: 'log-' + Date.now(),
      device_id: newDev.id,
      idpel: newDev.idpel,
      nama_pelanggan: newDev.nama_pelanggan,
      command: 'PLNON',
      sender_name: currentUser?.nama || 'Petugas',
      sender_role: currentUser?.role || 'admin',
      status: 'SUCCESS',
      response_message: 'Instalasi Baru S41 Terdaftar',
      timestamp: new Date().toISOString()
    });
  };

  // Confirm Relocation
  const handleConfirmRelocation = (updatedDev: S41Device, record: RelocationRecord) => {
    setDevices((prev) => prev.map((d) => (d.id === updatedDev.id ? updatedDev : d)));
    setRelocations((prev) => [record, ...prev]);
    saveRelocationToSupabase(record, updatedDev);
    
    handleAddLog({
      id: 'log-' + Date.now(),
      device_id: updatedDev.id,
      idpel: updatedDev.idpel,
      nama_pelanggan: updatedDev.nama_pelanggan,
      command: 'PLNSTATUS',
      sender_name: currentUser?.nama || 'Admin',
      sender_role: currentUser?.role || 'admin',
      status: 'SUCCESS',
      response_message: `Relokasi dari IDPEL ${record.idpel_asal} ke ${record.idpel_tujuan} berhasil dicatat.`,
      timestamp: new Date().toISOString()
    });

    setRelocatingDevice(null);
    setSelectedDevice(null);
    alert(`Relokasi S41 Berhasil! Alat kini ditugaskan ke IDPEL ${updatedDev.idpel} (${updatedDev.nama_pelanggan}).`);
  };

  // Quick Action on Card (One-click toggle)
  const handleQuickToggle = async (e: React.MouseEvent, device: S41Device) => {
    e.stopPropagation();
    const cmd = device.status_relay === 'ON' ? 'PLNOFF' : 'PLNON';
    const actionWord = cmd === 'PLNOFF' ? 'MEMADAMKAN' : 'MENYALAKAN';

    if (!confirm(`Konfirmasi: Injek SMS untuk ${actionWord} listrik pelanggan ${device.nama_pelanggan} (${device.idpel})?`)) {
      return;
    }

    try {
      const res = await executeSmsCommand(device, cmd, 'direct');
      const updated: S41Device = {
        ...device,
        status_relay: cmd === 'PLNOFF' ? 'OFF' : 'ON',
        updated_at: new Date().toISOString()
      };
      handleUpdateDevice(updated);

      handleAddLog({
        id: 'log-' + Date.now(),
        device_id: device.id,
        idpel: device.idpel,
        nama_pelanggan: device.nama_pelanggan,
        command: cmd,
        sender_name: currentUser?.nama || 'Petugas',
        sender_role: currentUser?.role || 'kordinator',
        status: res.success ? 'SUCCESS' : 'FAILED',
        response_message: res.response || res.message,
        timestamp: new Date().toISOString()
      });

      alert(res.response || `Berhasil ${actionWord} listrik!`);
    } catch (err: any) {
      alert('Gagal: ' + err.message);
    }
  };

  // Selection toggle
  const toggleSelect = (id: string) => {
    setSelectedIds((prev) => 
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const selectAllFiltered = () => {
    if (selectedIds.length === filteredDevices.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredDevices.map((d) => d.id));
    }
  };

  // Filtered devices calculation
  const filteredDevices = devices.filter((d) => {
    const matchesSearch = 
      d.nama_pelanggan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.idpel.includes(searchTerm) ||
      d.nomor_sim.includes(searchTerm) ||
      d.tiang_jtr.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.alamat.toLowerCase().includes(searchTerm.toLowerCase());

    if (!matchesSearch) return false;

    if (filterStatus === 'MENUNGGAK') return d.status_tunggakan === 'MENUNGGAK';
    if (filterStatus === 'OFF') return d.status_relay === 'OFF';
    if (filterStatus === 'ON') return d.status_relay === 'ON';
    return true;
  });

  // Selected device objects
  const selectedDeviceObjects = devices.filter((d) => selectedIds.includes(d.id));

  // Summary Metrics
  const totalCount = devices.length;
  const offCount = devices.filter((d) => d.status_relay === 'OFF').length;
  const onCount = devices.filter((d) => d.status_relay === 'ON').length;
  const menunggakCount = devices.filter((d) => d.status_tunggakan === 'MENUNGGAK').length;

  // Gatekeeper: If user is not logged in, render login screen
  if (!currentUser) {
    return <LoginModal onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col font-sans pb-24 select-none">
      
      {/* Sticky Header */}
      <Header
        user={currentUser}
        onLogout={handleLogout}
        onOpenPocketBook={() => setIsPocketBookOpen(true)}
        onOpenLogs={() => setIsLogsOpen(true)}
        onOpenConfig={() => setIsConfigOpen(true)}
        onOpenUsers={() => setIsUserMgmtOpen(true)}
        isSupabaseConnected={hasSupabaseConfig()}
      />

      <main className="max-w-md w-full mx-auto px-4 pt-3 flex-1 space-y-3">

        {/* Cloud Sync Status Notice */}
        {isCloudSynced ? (
          <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-2 rounded-xl text-[11px] flex items-center justify-between">
            <div className="flex items-center gap-1.5 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>Database Cloud Supabase Terhubung & Sinkron</span>
            </div>
            <span className="text-[10px] bg-emerald-200/60 px-1.5 py-0.5 rounded font-mono font-bold">
              ONLINE
            </span>
          </div>
        ) : cloudNotice ? (
          <div 
            onClick={() => setIsConfigOpen(true)}
            className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 text-blue-900 p-2.5 rounded-xl text-[11px] flex items-center justify-between cursor-pointer hover:border-blue-400 transition-all shadow-xs"
          >
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-blue-600 shrink-0" />
              <div>
                <p className="font-black text-blue-950">Supabase Terkoneksi: lkpzvlrukbreklhbcywx</p>
                <p className="text-[10px] text-blue-700">Klik di sini untuk melihat & menyalin Skrip SQL tabel database.</p>
              </div>
            </div>
            <span className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-[10px] px-2 py-1 rounded-lg shrink-0 shadow-xs">
              Salin SQL
            </span>
          </div>
        ) : null}

        {/* METRICS SUMMARY CARDS */}
        <div className="grid grid-cols-4 gap-2">
          <div className="bg-white p-2.5 rounded-2xl border border-slate-200 text-center shadow-2xs">
            <span className="text-[10px] text-slate-500 font-bold block">TOTAL S41</span>
            <span className="text-base font-black text-slate-900">{totalCount}</span>
          </div>
          <div className="bg-emerald-50/70 p-2.5 rounded-2xl border border-emerald-200 text-center shadow-2xs">
            <span className="text-[10px] text-emerald-700 font-bold block">MENYALA</span>
            <span className="text-base font-black text-emerald-800">{onCount}</span>
          </div>
          <div className="bg-red-50/70 p-2.5 rounded-2xl border border-red-200 text-center shadow-2xs">
            <span className="text-[10px] text-red-700 font-bold block">PADAM</span>
            <span className="text-base font-black text-red-800">{offCount}</span>
          </div>
          <div className="bg-amber-50/70 p-2.5 rounded-2xl border border-amber-200 text-center shadow-2xs">
            <span className="text-[10px] text-amber-700 font-bold block">TUNGGAK</span>
            <span className="text-base font-black text-amber-800">{menunggakCount}</span>
          </div>
        </div>

        {/* SEARCH & FILTER CONTROLS */}
        <div className="bg-white p-3 rounded-2xl border border-slate-200 shadow-2xs space-y-2.5">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Cari IDPEL, Nama, Tiang, No SIM..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex items-center justify-between gap-1 overflow-x-auto text-[11px]">
            <div className="flex gap-1">
              {(['ALL', 'MENUNGGAK', 'OFF', 'ON'] as const).map((filter) => (
                <button
                  key={filter}
                  onClick={() => setFilterStatus(filter)}
                  className={`px-2.5 py-1 rounded-xl font-bold transition-all shrink-0 ${
                    filterStatus === filter
                      ? 'bg-[#005DA6] text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {filter === 'ALL' ? 'Semua' : filter}
                </button>
              ))}
            </div>

            {/* Selection Mode Toggle */}
            <button
              onClick={() => {
                setIsSelectionMode(!isSelectionMode);
                setSelectedIds([]);
              }}
              className={`px-2 py-1 rounded-xl font-bold flex items-center gap-1 shrink-0 transition-all ${
                isSelectionMode
                  ? 'bg-amber-500 text-slate-950 font-black'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>{isSelectionMode ? 'Batal Kolektif' : 'Pilih Kolektif'}</span>
            </button>
          </div>

          {/* Select All Row if in selection mode */}
          {isSelectionMode && (
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
              <button
                onClick={selectAllFiltered}
                className="flex items-center gap-1.5 text-blue-600 font-bold"
              >
                {selectedIds.length === filteredDevices.length && filteredDevices.length > 0 ? (
                  <CheckSquare className="w-4 h-4" />
                ) : (
                  <Square className="w-4 h-4" />
                )}
                <span>Pilih Semua ({selectedIds.length}/{filteredDevices.length})</span>
              </button>

              {selectedIds.length > 0 && (
                <button
                  onClick={() => setIsBatchOpen(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded-xl font-black text-[11px] flex items-center gap-1 shadow-md animate-pulse"
                >
                  <span>Eksekusi ({selectedIds.length})</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          )}
        </div>

        {/* DEVICE LIST */}
        <div className="space-y-2">
          {filteredDevices.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 space-y-2">
              <Zap className="w-8 h-8 mx-auto opacity-30 text-slate-400" />
              <p className="text-xs font-semibold">Tidak ada pelanggan/alat S41 ditemukan.</p>
            </div>
          ) : (
            filteredDevices.map((device) => {
              const isSelected = selectedIds.includes(device.id);

              return (
                <div
                  key={device.id}
                  onClick={() => {
                    if (isSelectionMode) {
                      toggleSelect(device.id);
                    } else {
                      setSelectedDevice(device);
                    }
                  }}
                  className={`bg-white rounded-2xl border p-3.5 transition-all shadow-2xs relative cursor-pointer active:scale-[0.99] ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50/50 ring-2 ring-blue-500/20'
                      : 'border-slate-200 hover:border-blue-300'
                  }`}
                >
                  {/* Top Line: IDPEL, Tunggakan & Relay Status */}
                  <div className="flex items-center justify-between mb-1.5">
                    <div className="flex items-center gap-1.5">
                      {isSelectionMode && (
                        <div className="mr-1 text-blue-600">
                          {isSelected ? <CheckSquare className="w-4 h-4" /> : <Square className="w-4 h-4 text-slate-400" />}
                        </div>
                      )}
                      <span className="font-mono text-xs font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                        {device.idpel}
                      </span>
                      <span className={`text-[9px] font-black px-1.5 py-0.5 rounded ${
                        device.status_tunggakan === 'MENUNGGAK' 
                          ? 'bg-red-100 text-red-700' 
                          : 'bg-emerald-100 text-emerald-700'
                      }`}>
                        {device.status_tunggakan}
                      </span>
                    </div>

                    {/* Relay Badge */}
                    <span className={`text-[10px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 ${
                      device.status_relay === 'ON'
                        ? 'bg-emerald-500 text-white'
                        : 'bg-red-600 text-white'
                    }`}>
                      <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
                      {device.status_relay === 'ON' ? 'MENYALA' : 'PADAM'}
                    </span>
                  </div>

                  {/* Customer Name & Tariff */}
                  <div className="mb-2">
                    <h3 className="font-black text-slate-900 text-sm truncate">
                      {device.nama_pelanggan}
                    </h3>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">
                      <span>{device.tarif_daya}</span>
                      <span>•</span>
                      <span>No. Meter: <strong className="font-mono text-slate-700">{device.nomor_meter}</strong></span>
                    </div>
                  </div>

                  {/* Bottom Meta & Quick Action Button */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100 text-[11px] text-slate-500">
                    <div className="space-y-0.5 font-mono text-[10px]">
                      <div className="flex items-center gap-1 text-blue-700 font-bold">
                        <Smartphone className="w-3 h-3" />
                        <span>{device.nomor_sim}</span>
                      </div>
                      <div className="flex items-center gap-1 text-slate-500">
                        <MapPin className="w-3 h-3 text-slate-400" />
                        <span>{device.tiang_jtr} • {device.unit_ulp}</span>
                      </div>
                    </div>

                    {/* Quick Trigger Button */}
                    {!isSelectionMode && (
                      <button
                        onClick={(e) => handleQuickToggle(e, device)}
                        className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1 shadow-sm transition-all active:scale-95 ${
                          device.status_relay === 'ON'
                            ? 'bg-red-50 text-red-700 hover:bg-red-100 border border-red-200'
                            : 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200'
                        }`}
                      >
                        {device.status_relay === 'ON' ? (
                          <>
                            <PowerOff className="w-3.5 h-3.5 text-red-600" />
                            <span>Putus Aliran</span>
                          </>
                        ) : (
                          <>
                            <Power className="w-3.5 h-3.5 text-emerald-600" />
                            <span>Sambung</span>
                          </>
                        )}
                      </button>
                    )}
                  </div>
                </div>
              );
            })
          )}
        </div>

      </main>

      {/* FLOATING ACTION BUTTON: TAMBAH S41 BARU */}
      <div className="fixed bottom-4 right-4 z-20 max-w-md mx-auto">
        <button
          onClick={() => setIsAddDeviceOpen(true)}
          className="bg-gradient-to-r from-[#005DA6] to-[#004882] hover:from-[#004882] hover:to-[#003664] text-white p-3.5 rounded-full shadow-xl shadow-blue-900/30 active:scale-95 flex items-center gap-2 font-bold text-xs"
        >
          <Plus className="w-5 h-5 text-yellow-300" />
          <span className="hidden sm:inline">Tambah S41</span>
        </button>
      </div>

      {/* MODALS */}
      {selectedDevice && (
        <DeviceDetailModal
          device={selectedDevice}
          currentUser={currentUser}
          onClose={() => setSelectedDevice(null)}
          onUpdateDevice={handleUpdateDevice}
          onAddLog={handleAddLog}
          onOpenRelocation={(dev) => {
            setRelocatingDevice(dev);
          }}
        />
      )}

      {relocatingDevice && (
        <RelocationModal
          device={relocatingDevice}
          currentUser={currentUser}
          onClose={() => setRelocatingDevice(null)}
          onConfirmRelocation={handleConfirmRelocation}
        />
      )}

      {isBatchOpen && (
        <BatchActionModal
          selectedDevices={selectedDeviceObjects}
          currentUser={currentUser}
          onClose={() => {
            setIsBatchOpen(false);
            setSelectedIds([]);
            setIsSelectionMode(false);
          }}
          onBatchComplete={(updated) => {
            setDevices((prev) => 
              prev.map((d) => {
                const match = updated.find((u) => u.id === d.id);
                return match || d;
              })
            );
          }}
          onAddLog={handleAddLog}
        />
      )}

      {isPocketBookOpen && (
        <PocketBookModal onClose={() => setIsPocketBookOpen(false)} />
      )}

      {isLogsOpen && (
        <LogAuditModal
          logs={logs}
          currentUser={currentUser}
          onClose={() => setIsLogsOpen(false)}
          onClearLogs={() => setLogs([])}
        />
      )}

      {isConfigOpen && (
        <SupabaseConfigModal
          onClose={() => setIsConfigOpen(false)}
          onSaveConfig={(_url, _key) => {
            // Config updated
          }}
        />
      )}

      {isAddDeviceOpen && (
        <AddDeviceModal
          onClose={() => setIsAddDeviceOpen(false)}
          onAddDevice={handleAddDevice}
        />
      )}

      {isUserMgmtOpen && (
        <UserManagementModal
          onClose={() => setIsUserMgmtOpen(false)}
        />
      )}

      {/* PWA Install Banner */}
      <InstallPrompt />

    </div>
  );
}

export default App;
