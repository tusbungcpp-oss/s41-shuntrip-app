import React, { useState } from 'react';
import { 
  X, 
  Power, 
  PowerOff, 
  RefreshCw, 
  ShieldAlert, 
  UserPlus, 
  UserMinus, 
  Users, 
  RotateCcw, 
  Smartphone, 
  Signal, 
  ArrowRightLeft,
  Lock
} from 'lucide-react';
import type { S41Device, UserProfile } from '../types';
import { executeSmsCommand, formatIndonesianPhone } from '../lib/smsEngine';

interface DeviceDetailModalProps {
  device: S41Device;
  currentUser: UserProfile;
  onClose: () => void;
  onUpdateDevice: (updated: S41Device) => void;
  onAddLog: (logData: any) => void;
  onOpenRelocation: (device: S41Device) => void;
}

export const DeviceDetailModal: React.FC<DeviceDetailModalProps> = ({
  device,
  currentUser,
  onClose,
  onUpdateDevice,
  onAddLog,
  onOpenRelocation,
}) => {
  const [activeTab, setActiveTab] = useState<'control' | 'info' | 'admin'>('control');
  const [loadingCommand, setLoadingCommand] = useState<string | null>(null);
  const [lastResponse, setLastResponse] = useState<string | null>(null);
  const [smsMode, setSmsMode] = useState<'direct' | 'native_app'>('direct');

  // Admin form inputs
  const [adminPhone, setAdminPhone] = useState('');
  const [delPhone, setDelPhone] = useState('');

  // Handle command execution
  const handleRunCommand = async (command: string, detailArg?: string) => {
    // Role check for restricted commands
    const isAdminOnly = ['SETADMIN', 'DELADMIN', 'RESETADMIN', 'PLNRESET'].some(c => command.startsWith(c));
    if (isAdminOnly && currentUser.role !== 'admin') {
      alert('Akses Ditolak: Perintah ini hanya boleh dieksekusi oleh ADMIN Sistem/Kantor.');
      return;
    }

    setLoadingCommand(command);
    setLastResponse(null);

    try {
      const result = await executeSmsCommand(device, command, smsMode);

      setLastResponse(result.response || result.message);

      // If status changed
      if (result.newRelayStatus || result.newSignalDbm) {
        const updated: S41Device = {
          ...device,
          status_relay: result.newRelayStatus || device.status_relay,
          signal_dbm: result.newSignalDbm || device.signal_dbm,
          updated_at: new Date().toISOString()
        };
        onUpdateDevice(updated);
      }

      // Record log
      onAddLog({
        id: 'log-' + Date.now(),
        device_id: device.id,
        idpel: device.idpel,
        nama_pelanggan: device.nama_pelanggan,
        command: command.split(':')[0],
        detail_arg: detailArg,
        sender_name: currentUser.nama,
        sender_role: currentUser.role,
        status: result.success ? 'SUCCESS' : 'FAILED',
        response_message: result.response || result.message,
        timestamp: new Date().toISOString()
      });

    } catch (err: any) {
      alert('Gagal mengeksekusi perintah SMS: ' + err.message);
    } finally {
      setLoadingCommand(null);
    }
  };

  // Check if SIM card is expiring soon (within 14 days)
  const isSimExpiringSoon = () => {
    const expDate = new Date(device.masa_aktif_sim).getTime();
    const today = new Date().getTime();
    const diffDays = (expDate - today) / (1000 * 3600 * 24);
    return diffDays < 15;
  };

  return (
    <div className="fixed inset-0 z-40 bg-slate-900/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] overflow-hidden flex flex-col shadow-2xl animate-in slide-in-from-bottom sm:zoom-in-95 duration-200">
        
        {/* Header Modal */}
        <div className="bg-[#005DA6] text-white p-4 relative shrink-0">
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 p-1 rounded-full bg-white/10 hover:bg-white/20 active:scale-95 text-white"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2 mb-1">
            <span className="font-mono text-xs bg-white/20 px-2 py-0.5 rounded font-bold">
              IDPEL: {device.idpel}
            </span>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${
              device.status_tunggakan === 'MENUNGGAK' ? 'bg-red-500 text-white animate-pulse' : 'bg-emerald-400 text-slate-900'
            }`}>
              {device.status_tunggakan}
            </span>
          </div>

          <h2 className="text-lg font-black truncate">{device.nama_pelanggan}</h2>
          
          <div className="flex items-center gap-3 text-xs text-blue-100 mt-1">
            <span className="flex items-center gap-1 font-mono">
              <Smartphone className="w-3.5 h-3.5 text-yellow-300" />
              {device.nomor_sim}
            </span>
            <span className="flex items-center gap-1">
              <Signal className="w-3.5 h-3.5 text-emerald-300" />
              {device.signal_dbm} dBm
            </span>
            <span className={`font-black px-2 py-0.5 rounded text-[11px] ${
              device.status_relay === 'ON' ? 'bg-emerald-500 text-white' : 'bg-red-600 text-white'
            }`}>
              RELAY: {device.status_relay === 'ON' ? 'MENYALA (NC)' : 'PADAM (NO)'}
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-200 bg-slate-50 shrink-0">
          <button
            onClick={() => setActiveTab('control')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-all ${
              activeTab === 'control' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            KONTROL UTAMA
          </button>
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-all ${
              activeTab === 'info' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            DETAIL & ASET
          </button>
          <button
            onClick={() => setActiveTab('admin')}
            className={`flex-1 py-2.5 text-xs font-bold text-center border-b-2 transition-all flex items-center justify-center gap-1 ${
              activeTab === 'admin' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            PENGATURAN ADMIN
            {currentUser.role !== 'admin' && <Lock className="w-3 h-3 text-amber-500" />}
          </button>
        </div>

        {/* Tab Content Body */}
        <div className="p-4 overflow-y-auto space-y-4 flex-1">

          {/* Mode Switcher: Injek Langsung vs SMS Bawaan */}
          <div className="bg-slate-100 p-2.5 rounded-xl flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-700">Metode Pengiriman:</span>
            <div className="flex items-center gap-1 bg-white p-1 rounded-lg border border-slate-200">
              <button
                onClick={() => setSmsMode('direct')}
                className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                  smsMode === 'direct' 
                    ? 'bg-blue-600 text-white shadow-xs' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Injek Langsung (APK)
              </button>
              <button
                onClick={() => setSmsMode('native_app')}
                className={`px-2 py-1 rounded text-[11px] font-bold transition-all ${
                  smsMode === 'native_app' 
                    ? 'bg-blue-600 text-white shadow-xs' 
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Aplikasi SMS HP
              </button>
            </div>
          </div>

          {/* TAB 1: KONTROL UTAMA */}
          {activeTab === 'control' && (
            <div className="space-y-4">
              {/* Main Action Buttons Grid */}
              <div className="grid grid-cols-2 gap-3">
                {/* NYALAKAN LISTRIK */}
                <button
                  disabled={loadingCommand !== null}
                  onClick={() => handleRunCommand('PLNON')}
                  className="p-4 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white rounded-2xl flex flex-col items-center justify-center gap-2 shadow-lg shadow-emerald-600/20 transition-all disabled:opacity-50"
                >
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    <Power className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-center">
                    <span className="font-black text-sm block">NYALAKAN LISTRIK</span>
                    <span className="text-[10px] text-emerald-100 font-mono">SMS: PLNON</span>
                  </div>
                </button>

                {/* PADAMKAN LISTRIK */}
                <button
                  disabled={loadingCommand !== null}
                  onClick={() => {
                    if (confirm(`PENTING: Yakin ingin MEMADAMKAN listrik untuk IDPEL ${device.idpel} (${device.nama_pelanggan})?`)) {
                      handleRunCommand('PLNOFF');
                    }
                  }}
                  className="p-4 bg-red-600 hover:bg-red-700 active:scale-95 text-white rounded-2xl flex flex-col items-center justify-center gap-2 shadow-lg shadow-red-600/20 transition-all disabled:opacity-50"
                >
                  <div className="w-12 h-12 rounded-full bg-white/20 flex items-center justify-center">
                    <PowerOff className="w-6 h-6 text-white" />
                  </div>
                  <div className="text-center">
                    <span className="font-black text-sm block">PADAMKAN LISTRIK</span>
                    <span className="text-[10px] text-red-100 font-mono">SMS: PLNOFF</span>
                  </div>
                </button>
              </div>

              {/* CEK STATUS BUTTON */}
              <button
                disabled={loadingCommand !== null}
                onClick={() => handleRunCommand('PLNSTATUS')}
                className="w-full py-3 px-4 bg-slate-800 hover:bg-slate-900 active:scale-[0.99] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 transition-all disabled:opacity-50 shadow-md"
              >
                <RefreshCw className={`w-4 h-4 text-cyan-400 ${loadingCommand === 'PLNSTATUS' ? 'animate-spin' : ''}`} />
                <span>CEK STATUS LENGKAP PERANGKAT (PLNSTATUS)</span>
              </button>

              {/* Live Response Box from S41 */}
              {lastResponse && (
                <div className="p-3 bg-slate-900 text-emerald-400 font-mono text-xs rounded-xl border border-slate-800 shadow-inner">
                  <div className="flex items-center justify-between text-[10px] text-slate-400 border-b border-slate-800 pb-1 mb-1">
                    <span>BALASAN SMS DARI S41 ({device.nomor_sim}):</span>
                    <span className="text-emerald-500 font-bold">TERVERIFIKASI</span>
                  </div>
                  <pre className="whitespace-pre-wrap font-sans text-xs leading-relaxed">{lastResponse}</pre>
                </div>
              )}
            </div>
          )}

          {/* TAB 2: DETAIL PELANGGAN & ASET */}
          {activeTab === 'info' && (
            <div className="space-y-3">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-2">
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">ID Pelanggan (IDPEL):</span>
                  <span className="font-mono font-bold text-slate-900">{device.idpel}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">Tarif / Daya:</span>
                  <span className="font-bold text-slate-900">{device.tarif_daya} (Max 5500 VA)</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">Nomor KWh Meter:</span>
                  <span className="font-mono font-bold text-slate-900">{device.nomor_meter}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">Nomor Kartu SIM S41:</span>
                  <span className="font-mono font-bold text-blue-700">{device.nomor_sim}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5 items-center">
                  <span className="text-slate-500">Masa Aktif SIM Card:</span>
                  <div className="flex items-center gap-1 font-bold">
                    <span className={isSimExpiringSoon() ? 'text-amber-600 font-black' : 'text-slate-800'}>
                      {device.masa_aktif_sim}
                    </span>
                    {isSimExpiringSoon() && (
                      <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.2 rounded font-black">
                        Perlu Isi Pulsa!
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">Tiang JTR / JTM:</span>
                  <span className="font-bold text-slate-900">{device.tiang_jtr || '-'}</span>
                </div>
                <div className="flex justify-between border-b border-slate-200 pb-1.5">
                  <span className="text-slate-500">Alamat Pemasangan:</span>
                  <span className="font-medium text-slate-800 text-right max-w-[200px]">{device.alamat}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Wilayah PLN:</span>
                  <span className="font-bold text-slate-900 text-right">{device.unit_ulp} • {device.unit_up3}</span>
                </div>
              </div>

              {/* ACTION: Relokasi Alat ke IDPEL Lain (Khusus Admin) */}
              <div className="pt-2">
                {currentUser.role === 'admin' ? (
                  <button
                    onClick={() => onOpenRelocation(device)}
                    className="w-full py-2.5 px-3 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 active:scale-[0.99] text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all"
                  >
                    <ArrowRightLeft className="w-4 h-4" />
                    <span>PINDAH / RELOKASI ALAT S41 KE IDPEL LAIN</span>
                  </button>
                ) : (
                  <div className="p-2.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-800 text-[11px] flex items-center gap-2">
                    <Lock className="w-4 h-4 shrink-0 text-amber-600" />
                    <span>Relokasi alat ke IDPEL lain hanya dapat dilakukan oleh akun <strong>ADMIN</strong>.</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: PENGATURAN ADMIN S41 (Slide 8 & 9) */}
          {activeTab === 'admin' && (
            <div className="space-y-4">
              {currentUser.role !== 'admin' ? (
                /* Locked for Kordinator */
                <div className="p-4 bg-amber-50 border-2 border-amber-200 rounded-2xl text-center space-y-2">
                  <div className="w-10 h-10 rounded-full bg-amber-100 text-amber-700 mx-auto flex items-center justify-center">
                    <Lock className="w-5 h-5" />
                  </div>
                  <h3 className="font-black text-amber-900 text-xs">AKSES KHUSUS ADMINISTRATOR SISTEM</h3>
                  <p className="text-[11px] text-amber-700 leading-relaxed">
                    Pengaturan nomor Admin alat S41 (<code className="font-mono bg-white px-1 py-0.5 rounded">SETADMIN</code>, <code className="font-mono bg-white px-1 py-0.5 rounded">DELADMIN</code>, <code className="font-mono bg-white px-1 py-0.5 rounded">RESETADMIN</code>) dan Factory Reset dikunci demi keamanan operasional lapangan.
                  </p>
                </div>
              ) : (
                /* Authorized for Admin */
                <div className="space-y-4">
                  {/* Warning banner */}
                  <div className="p-2.5 bg-blue-50 border border-blue-200 rounded-xl text-[11px] text-blue-800 flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
                    <div>
                      <strong>Note Penting PLN:</strong> Nomor yang didaftarkan sebagai Admin otomatis memiliki wewenang mengontrol alat ini. Format wajib diawali dengan <code className="font-bold">+62</code>.
                    </div>
                  </div>

                  {/* FORM 1: SETADMIN */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-[11px] font-bold text-slate-800">
                      1. TAMBAHKAN NOMOR ADMIN (SETADMIN)
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={adminPhone}
                        onChange={(e) => setAdminPhone(e.target.value)}
                        placeholder="Contoh: 081665785645"
                        className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                      <button
                        disabled={!adminPhone || loadingCommand !== null}
                        onClick={() => {
                          const formatted = formatIndonesianPhone(adminPhone);
                          handleRunCommand(`SETADMIN:${formatted}`, formatted);
                          setAdminPhone('');
                        }}
                        className="px-3 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 disabled:opacity-50"
                      >
                        <UserPlus className="w-3.5 h-3.5" />
                        <span>Daftarkan</span>
                      </button>
                    </div>
                  </div>

                  {/* FORM 2: DELADMIN */}
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                    <label className="block text-[11px] font-bold text-slate-800">
                      2. HAPUS NOMOR ADMIN (DELADMIN)
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={delPhone}
                        onChange={(e) => setDelPhone(e.target.value)}
                        placeholder="Contoh: 081665785645"
                        className="flex-1 px-3 py-1.5 text-xs rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-blue-500 focus:outline-none"
                      />
                      <button
                        disabled={!delPhone || loadingCommand !== null}
                        onClick={() => {
                          const formatted = formatIndonesianPhone(delPhone);
                          handleRunCommand(`DELADMIN:${formatted}`, formatted);
                          setDelPhone('');
                        }}
                        className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 disabled:opacity-50"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                        <span>Hapus</span>
                      </button>
                    </div>
                  </div>

                  {/* BUTTON: LISTADMIN */}
                  <button
                    disabled={loadingCommand !== null}
                    onClick={() => handleRunCommand('LISTADMIN')}
                    className="w-full py-2 px-3 bg-slate-700 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2"
                  >
                    <Users className="w-4 h-4 text-blue-300" />
                    <span>LIHAT DAFTAR ADMIN RESMI (LISTADMIN)</span>
                  </button>

                  {/* RESET BUTTONS (DANGEROUS) */}
                  <div className="pt-2 border-t border-slate-200 grid grid-cols-2 gap-2">
                    <button
                      disabled={loadingCommand !== null}
                      onClick={() => {
                        if (confirm(`PERINGATAN KRITIS: Yakin ingin MENGHAPUS SEMUA ADMIN pada alat ini (RESETADMIN)?`)) {
                          handleRunCommand('RESETADMIN');
                        }
                      }}
                      className="py-2 px-2 bg-red-100 hover:bg-red-200 text-red-800 border border-red-300 rounded-lg font-bold text-[11px] flex items-center justify-center gap-1"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>RESET ADMIN</span>
                    </button>

                    <button
                      disabled={loadingCommand !== null}
                      onClick={() => {
                        if (confirm(`Yakin ingin me-restart modul mikrokontroler S41 (PLNRESET)?`)) {
                          handleRunCommand('PLNRESET');
                        }
                      }}
                      className="py-2 px-2 bg-red-100 hover:bg-red-200 text-red-800 border border-red-300 rounded-lg font-bold text-[11px] flex items-center justify-center gap-1"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>RESET DEVICE</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
