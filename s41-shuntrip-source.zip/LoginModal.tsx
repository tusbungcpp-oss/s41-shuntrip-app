import React, { useState } from 'react';
import { ShieldCheck, Radio, KeyRound, User, ArrowRight, Info, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import type { UserProfile, UserRole } from '../types';
import { authenticateUser } from '../lib/authService';

interface LoginModalProps {
  onLogin: (profile: UserProfile) => void;
}

export const LoginModal: React.FC<LoginModalProps> = ({ onLogin }) => {
  const [selectedRole, setSelectedRole] = useState<UserRole>('admin');
  const [nip, setNip] = useState('9418658ZY');
  const [nama, setNama] = useState('Ir. Ahmad Afandi, S.T., M.M. IPP');
  const [password, setPassword] = useState('pln123');
  const [unitName, setUnitName] = useState('UP3 Watampone - UID Sulselrabar');
  const [isLoading, setIsLoading] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const handleRoleSelect = (role: UserRole) => {
    setSelectedRole(role);
    setAuthError(null);
    if (role === 'admin') {
      setNip('9418658ZY');
      setNama('Ir. Ahmad Afandi, S.T., M.M. IPP');
      setUnitName('Kantor Induk / UP3 Watampone');
    } else {
      setNip('9620112ZY');
      setNama('Ruslan (Kordinator Lapangan)');
      setUnitName('ULP Patangkai - Lapangan');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nip || !password) return;

    setIsLoading(true);
    setAuthError(null);

    const res = await authenticateUser(nip, password);
    setIsLoading(false);

    if (res.success && res.user) {
      onLogin(res.user);
    } else {
      // If table pln_users is not yet created in Supabase (or offline), allow fallback demo
      if (res.message?.includes('not find') || res.message?.includes('schema cache')) {
        const profile: UserProfile = {
          id: selectedRole === 'admin' ? 'user-admin-1' : 'user-kord-1',
          nip,
          nama,
          role: selectedRole,
          unit_name: unitName,
          phone: selectedRole === 'admin' ? '+6281575464944' : '+6281234567890'
        };
        onLogin(profile);
      } else {
        setAuthError(res.message || 'Login gagal.');
      }
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header Branding */}
        <div className="bg-gradient-to-br from-[#005DA6] to-[#003664] p-6 text-white text-center relative overflow-hidden">
          <div className="absolute -right-6 -bottom-6 w-28 h-28 bg-white/10 rounded-full blur-xl pointer-events-none"></div>
          
          <div className="w-16 h-16 bg-white rounded-full mx-auto p-2 mb-3 shadow-lg flex items-center justify-center">
            <img src="/logo-s41.svg" alt="S41 Logo" className="w-full h-full object-contain" />
          </div>
          
          <h1 className="text-xl font-black tracking-tight">S41 SHUNTRIP MOBILE</h1>
          <p className="text-xs text-blue-200 font-medium mt-1">
            Sistem Kontrol & Pemutusan Cerdas Jarak Jauh
          </p>
          <div className="inline-block mt-2 bg-[#FED400] text-[#003664] text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase tracking-wider">
            PLN Danantara Indonesia
          </div>
        </div>

        {/* Role Selector Tabs */}
        <div className="p-5">
          <label className="block text-xs font-bold text-slate-700 mb-2">
            PILIH PERAN / ROLE AKSES:
          </label>
          <div className="grid grid-cols-2 gap-2 mb-4">
            <button
              type="button"
              onClick={() => handleRoleSelect('admin')}
              className={`p-3 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                selectedRole === 'admin'
                  ? 'border-blue-600 bg-blue-50/70 shadow-sm'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                  selectedRole === 'admin' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  <ShieldCheck className="w-4 h-4" />
                </span>
                {selectedRole === 'admin' && (
                  <CheckCircle2 className="w-4 h-4 text-blue-600" />
                )}
              </div>
              <div>
                <p className="text-xs font-black text-slate-900">ADMIN</p>
                <p className="text-[10px] text-slate-500 font-medium">Sistem & Kantor</p>
              </div>
            </button>

            <button
              type="button"
              onClick={() => handleRoleSelect('kordinator')}
              className={`p-3 rounded-xl border-2 text-left transition-all flex flex-col justify-between ${
                selectedRole === 'kordinator'
                  ? 'border-emerald-600 bg-emerald-50/70 shadow-sm'
                  : 'border-slate-200 hover:border-slate-300 bg-white'
              }`}
            >
              <div className="flex items-center justify-between w-full mb-1">
                <span className={`w-7 h-7 rounded-lg flex items-center justify-center ${
                  selectedRole === 'kordinator' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                }`}>
                  <Radio className="w-4 h-4" />
                </span>
                {selectedRole === 'kordinator' && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                )}
              </div>
              <div>
                <p className="text-xs font-black text-slate-900">KORDINATOR</p>
                <p className="text-[10px] text-slate-500 font-medium">Operasional Lapangan</p>
              </div>
            </button>
          </div>

          {/* Role Brief Explanations */}
          <div className="bg-slate-50 rounded-xl p-2.5 mb-4 text-[11px] border border-slate-200 text-slate-600 flex items-start gap-2">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div>
              {selectedRole === 'admin' ? (
                <span>
                  <strong>Hak Akses Admin:</strong> Kontrol penuh, Relokasi alat ke IDPEL lain, Manajemen nomor Admin S41 (<code className="text-blue-700">SETADMIN</code>, <code className="text-blue-700">RESET</code>), dan eksekusi.
                </span>
              ) : (
                <span>
                  <strong>Hak Akses Kordinator:</strong> Monitoring pelanggan, Eksekusi tunggal & kolektif (<code className="text-emerald-700">PLNON</code>, <code className="text-emerald-700">PLNOFF</code>, <code className="text-emerald-700">STATUS</code>), dan dokumentasi lapangan.
                </span>
              )}
            </div>
          </div>

          {/* Error message */}
          {authError && (
            <div className="mb-3 p-2.5 bg-red-50 border border-red-200 rounded-xl text-red-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                NIP / ID PETUGAS PLN
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <User className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  required
                  value={nip}
                  onChange={(e) => setNip(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500 font-mono"
                  placeholder="Contoh: 9418658ZY"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                NAMA LENGKAP
              </label>
              <input
                type="text"
                required
                value={nama}
                onChange={(e) => setNama(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                KATA SANDI / PIN
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-slate-400">
                  <KeyRound className="w-4 h-4" />
                </div>
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="******"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full mt-2 bg-gradient-to-r from-[#005DA6] to-[#004882] hover:from-[#004882] hover:to-[#003664] text-white py-2.5 px-4 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-blue-500/25 active:scale-[0.99] transition-all disabled:opacity-50"
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>MEMVERIFIKASI KE SUPABASE...</span>
                </>
              ) : (
                <>
                  <span>MASUK SEBAGAI {selectedRole.toUpperCase()}</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

        </div>

      </div>
    </div>
  );
};
