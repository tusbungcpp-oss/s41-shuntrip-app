import React, { useState } from 'react';
import { X, Plus, CheckCircle2 } from 'lucide-react';
import type { S41Device } from '../types';
import { formatIndonesianPhone } from '../lib/smsEngine';

interface AddDeviceModalProps {
  onClose: () => void;
  onAddDevice: (newDevice: S41Device) => void;
}

export const AddDeviceModal: React.FC<AddDeviceModalProps> = ({
  onClose,
  onAddDevice,
}) => {
  const [idpel, setIdpel] = useState('');
  const [nama, setNama] = useState('');
  const [tarifDaya, setTarifDaya] = useState('R1/900 VA');
  const [nomorMeter, setNomorMeter] = useState('');
  const [nomorSim, setNomorSim] = useState('');
  const [masaAktif, setMasaAktif] = useState(
    new Date(Date.now() + 30 * 24 * 3600 * 1000).toISOString().split('T')[0]
  );
  const [tiangJtr, setTiangJtr] = useState('');
  const [alamat, setAlamat] = useState('');
  const [statusTunggakan, setStatusTunggakan] = useState<'MENUNGGAK' | 'LUNAS'>('MENUNGGAK');
  const [ulp, setUlp] = useState('ULP Patangkai');
  const [up3] = useState('UP3 Watampone');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!idpel || !nama || !nomorSim || !nomorMeter) {
      alert('Harap lengkapi semua data wajib bertanda bintang (*).');
      return;
    }

    const device: S41Device = {
      id: 'dev-' + Date.now(),
      idpel,
      nama_pelanggan: nama,
      tarif_daya: tarifDaya,
      nomor_meter: nomorMeter,
      nomor_sim: formatIndonesianPhone(nomorSim),
      masa_aktif_sim: masaAktif,
      tiang_jtr: tiangJtr || 'TR-01',
      alamat: alamat || 'Wilayah Kerja ' + ulp,
      status_relay: 'ON',
      status_tunggakan: statusTunggakan,
      signal_dbm: -68,
      uptime: '0d 1h',
      unit_ulp: ulp,
      unit_up3: up3,
      unit_uid: 'UID Sulselrabar',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    onAddDevice(device);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#005DA6] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Plus className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">REGISTRASI S41 BARU</h2>
              <p className="text-[10px] text-blue-100">Pasang Modul ke Pelanggan PLN</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-3 flex-1 overflow-y-auto text-xs">
          
          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ID PELANGGAN (IDPEL) *
            </label>
            <input
              type="text"
              required
              value={idpel}
              onChange={(e) => setIdpel(e.target.value)}
              placeholder="Contoh: 541200987123"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono text-xs"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              NAMA PELANGGAN *
            </label>
            <input
              type="text"
              required
              value={nama}
              onChange={(e) => setNama(e.target.value)}
              placeholder="Contoh: Bpk. Syamsuddin"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                TARIF / DAYA
              </label>
              <select
                value={tarifDaya}
                onChange={(e) => setTarifDaya(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white text-xs"
              >
                <option value="R1/450 VA">R1 / 450 VA</option>
                <option value="R1/900 VA">R1 / 900 VA</option>
                <option value="R1/1300 VA">R1 / 1300 VA</option>
                <option value="R1/2200 VA">R1 / 2200 VA</option>
                <option value="B1/5500 VA">B1 / 5500 VA</option>
              </select>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                NO. KWH METER *
              </label>
              <input
                type="text"
                required
                value={nomorMeter}
                onChange={(e) => setNomorMeter(e.target.value)}
                placeholder="12345678"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              NOMOR SIM CARD S41 (MICRO SIM) *
            </label>
            <input
              type="text"
              required
              value={nomorSim}
              onChange={(e) => setNomorSim(e.target.value)}
              placeholder="08123456789 (Otomatis format +62)"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 font-mono text-xs"
            />
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                MASA AKTIF SIM CARD
              </label>
              <input
                type="date"
                value={masaAktif}
                onChange={(e) => setMasaAktif(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                STATUS TAGIHAN
              </label>
              <select
                value={statusTunggakan}
                onChange={(e) => setStatusTunggakan(e.target.value as any)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 bg-white text-xs font-bold"
              >
                <option value="MENUNGGAK">MENUNGGAK</option>
                <option value="LUNAS">LUNAS</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                NO. TIANG JTR
              </label>
              <input
                type="text"
                value={tiangJtr}
                onChange={(e) => setTiangJtr(e.target.value)}
                placeholder="TR-PTK-010"
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                UNIT ULP
              </label>
              <input
                type="text"
                value={ulp}
                onChange={(e) => setUlp(e.target.value)}
                className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-700 mb-1">
              ALAMAT LENGKAP
            </label>
            <input
              type="text"
              value={alamat}
              onChange={(e) => setAlamat(e.target.value)}
              placeholder="Alamat rumah / jalan..."
              className="w-full px-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 text-xs"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all active:scale-[0.99] flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>SIMPAN ALAT S41 KE DATABASE</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
