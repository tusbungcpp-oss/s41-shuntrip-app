import React, { useState } from 'react';
import { 
  X, 
  Database, 
  Key, 
  Globe, 
  CheckCircle, 
  Copy, 
  FileCode
} from 'lucide-react';
import { SUPABASE_SQL_SCHEMA } from '../lib/supabase';

interface SupabaseConfigModalProps {
  onClose: () => void;
  onSaveConfig: (url: string, key: string) => void;
}

export const SupabaseConfigModal: React.FC<SupabaseConfigModalProps> = ({
  onClose,
  onSaveConfig,
}) => {
  const [url, setUrl] = useState(localStorage.getItem('s41_supabase_url') || '');
  const [key, setKey] = useState(localStorage.getItem('s41_supabase_key') || '');
  const [copied, setCopied] = useState(false);
  const [showSql, setShowSql] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    localStorage.setItem('s41_supabase_url', url.trim());
    localStorage.setItem('s41_supabase_key', key.trim());
    onSaveConfig(url.trim(), key.trim());
    alert('Koneksi Supabase berhasil disimpan!');
    onClose();
  };

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_SQL_SCHEMA);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#005DA6] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Database className="w-5 h-5 text-emerald-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">KONEKSI SUPABASE DATABASE</h2>
              <p className="text-[10px] text-blue-100">Konfigurasi Cloud PostgreSQL Realtime</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto text-xs">
          
          <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-900">
            <p className="font-semibold">
              Status Penyimpanan: <strong>Lokal & Siap Cloud Supabase</strong>
            </p>
            <p className="text-[11px] mt-0.5 text-emerald-800">
              Aplikasi saat ini aktif menyimpan data di memori perangkat. Anda dapat menghubungkan proyek Supabase Anda kapan saja dengan memasukkan URL & Anon Key di bawah ini.
            </p>
          </div>

          <form onSubmit={handleSave} className="space-y-3">
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                SUPABASE PROJECT URL
              </label>
              <div className="relative">
                <Globe className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="https://xyzabcdefg.supabase.co"
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono text-xs"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                SUPABASE ANON PUBLIC KEY
              </label>
              <div className="relative">
                <Key className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
                <input
                  type="password"
                  value={key}
                  onChange={(e) => setKey(e.target.value)}
                  placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6..."
                  className="w-full pl-9 pr-3 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono text-xs"
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl shadow-md transition-all active:scale-[0.99]"
            >
              SIMPAN KONEKSI SUPABASE
            </button>
          </form>

          {/* SQL Schema Generator Section */}
          <div className="pt-3 border-t border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-slate-800 flex items-center gap-1.5">
                <FileCode className="w-4 h-4 text-blue-600" />
                SKEMA SQL DATABASE (TINGGAL SALIN)
              </span>
              <button
                type="button"
                onClick={handleCopySql}
                className="px-2.5 py-1 bg-slate-800 hover:bg-slate-900 text-white rounded-lg font-bold text-[10px] flex items-center gap-1 transition-all"
              >
                {copied ? <CheckCircle className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Tersalin!' : 'Salin SQL'}</span>
              </button>
            </div>

            <p className="text-[11px] text-slate-500 mb-2">
              Salin kode SQL ini dan tempel di menu <strong>SQL Editor</strong> di dashboard Supabase Anda untuk otomatis membuat tabel perangkat, unit PLN, relokasi, dan log perintah.
            </p>

            <button
              type="button"
              onClick={() => setShowSql(!showSql)}
              className="text-blue-600 hover:text-blue-700 font-bold text-[11px] underline"
            >
              {showSql ? 'Sembunyikan Kode SQL' : 'Lihat Kode Skema SQL'}
            </button>

            {showSql && (
              <pre className="mt-2 p-3 bg-slate-900 text-slate-200 font-mono text-[10px] rounded-xl max-h-48 overflow-y-auto leading-relaxed">
                {SUPABASE_SQL_SCHEMA}
              </pre>
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
