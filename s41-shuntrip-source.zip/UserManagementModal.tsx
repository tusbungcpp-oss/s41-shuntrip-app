import React, { useState, useEffect } from 'react';
import { 
  X, 
  Users, 
  UserPlus, 
  RefreshCw
} from 'lucide-react';
import type { DbUser } from '../lib/authService';
import { fetchAllUsers, createNewUser, toggleUserStatus } from '../lib/authService';

interface UserManagementModalProps {
  onClose: () => void;
}

export const UserManagementModal: React.FC<UserManagementModalProps> = ({ onClose }) => {
  const [users, setUsers] = useState<DbUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAdding, setIsAdding] = useState(false);

  // New User Form State
  const [nip, setNip] = useState('');
  const [nama, setNama] = useState('');
  const [password, setPassword] = useState('pln123');
  const [role, setRole] = useState<'admin' | 'kordinator'>('kordinator');
  const [unitName, setUnitName] = useState('ULP Patangkai - Lapangan');
  const [noHp, setNoHp] = useState('');

  const loadUsers = async () => {
    setLoading(true);
    const data = await fetchAllUsers();
    setUsers(data);
    setLoading(false);
  };

  useEffect(() => {
    loadUsers();
  }, []);

  const handleCreateUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!nip || !nama || !noHp) {
      alert('Harap isi semua kolom wajib.');
      return;
    }

    const res = await createNewUser({
      nip,
      nama,
      password,
      role,
      unit_name: unitName,
      no_hp: noHp,
      is_active: true
    });

    if (res.success) {
      alert(`Petugas ${nama} berhasil didaftarkan ke Supabase!`);
      setIsAdding(false);
      setNip('');
      setNama('');
      setNoHp('');
      loadUsers();
    } else {
      alert('Gagal menambah petugas: ' + res.message);
    }
  };

  const handleToggle = async (user: DbUser) => {
    const actionText = user.is_active ? 'menonaktifkan' : 'mengaktifkan';
    if (!confirm(`Yakin ingin ${actionText} akun petugas ${user.nama}?`)) return;

    const ok = await toggleUserStatus(user.id, user.is_active);
    if (ok) {
      setUsers(prev => prev.map(u => u.id === user.id ? { ...u, is_active: !u.is_active } : u));
    } else {
      alert('Gagal mengubah status petugas.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#003664] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <Users className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">MANAJEMEN PENGGUNA PLN</h2>
              <p className="text-[10px] text-blue-200">Tabel Petugas & Kordinator Supabase</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 space-y-3 flex-1 overflow-y-auto text-xs">

          {/* Action Header */}
          <div className="flex items-center justify-between">
            <span className="font-bold text-slate-800 text-xs">
              Daftar Petugas Terdaftar ({users.length})
            </span>
            <div className="flex gap-1.5">
              <button
                onClick={loadUsers}
                className="p-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-700"
                title="Muat Ulang"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              </button>
              <button
                onClick={() => setIsAdding(!isAdding)}
                className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-bold text-xs flex items-center gap-1 shadow-xs"
              >
                <UserPlus className="w-3.5 h-3.5" />
                <span>{isAdding ? 'Tutup Form' : 'Tambah Petugas'}</span>
              </button>
            </div>
          </div>

          {/* Form Tambah Petugas */}
          {isAdding && (
            <form onSubmit={handleCreateUser} className="bg-slate-50 p-3.5 rounded-2xl border border-slate-300 space-y-2.5 animate-in fade-in">
              <span className="font-black text-slate-900 block text-xs border-b pb-1">
                REGISTRASI PETUGAS BARU:
              </span>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-0.5">NIP PETUGAS *</label>
                  <input
                    type="text"
                    required
                    value={nip}
                    onChange={(e) => setNip(e.target.value)}
                    placeholder="9418658ZY"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-0.5">ROLE AKSES</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as any)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-bold text-xs"
                  >
                    <option value="kordinator">KORDINATOR (Lapangan)</option>
                    <option value="admin">ADMIN (Sistem)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-0.5">NAMA LENGKAP *</label>
                <input
                  type="text"
                  required
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="Nama Lengkap Petugas"
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-0.5">NO. HP *</label>
                  <input
                    type="text"
                    required
                    value={noHp}
                    onChange={(e) => setNoHp(e.target.value)}
                    placeholder="08123456789"
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-slate-700 mb-0.5">PASSWORD AWAL</label>
                  <input
                    type="text"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg font-mono text-xs"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-700 mb-0.5">UNIT KERJA PLN</label>
                <input
                  type="text"
                  value={unitName}
                  onChange={(e) => setUnitName(e.target.value)}
                  placeholder="ULP Patangkai / UP3 Watampone"
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg shadow-xs"
              >
                Simpan Petugas ke Supabase
              </button>
            </form>
          )}

          {/* List Users */}
          <div className="space-y-2">
            {loading ? (
              <div className="text-center py-8 text-slate-400">Memuat data petugas dari Supabase...</div>
            ) : users.length === 0 ? (
              <div className="p-4 bg-slate-50 border rounded-xl text-center text-slate-500">
                Tabel <code className="font-mono font-bold">pln_users</code> belum dibuat di Supabase, atau belum ada user.
              </div>
            ) : (
              users.map((u) => (
                <div
                  key={u.id}
                  className={`p-3 rounded-xl border transition-all text-xs flex items-center justify-between ${
                    u.is_active ? 'bg-white border-slate-200' : 'bg-slate-100 border-slate-300 opacity-60'
                  }`}
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-1.5">
                      <span className="font-bold text-slate-900">{u.nama}</span>
                      <span className={`text-[9px] font-black px-1.5 py-0.2 rounded uppercase ${
                        u.role === 'admin' ? 'bg-amber-100 text-amber-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {u.role}
                      </span>
                    </div>

                    <div className="text-[11px] text-slate-500 flex items-center gap-2 font-mono">
                      <span>NIP: {u.nip}</span>
                      <span>•</span>
                      <span>{u.no_hp}</span>
                    </div>

                    <div className="text-[10px] text-slate-400">
                      {u.unit_name}
                    </div>
                  </div>

                  {/* Status Toggle Button */}
                  <button
                    onClick={() => handleToggle(u)}
                    className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition-all ${
                      u.is_active
                        ? 'bg-emerald-50 text-emerald-700 border-emerald-300 hover:bg-emerald-100'
                        : 'bg-red-50 text-red-700 border-red-300 hover:bg-red-100'
                    }`}
                  >
                    {u.is_active ? 'Aktif' : 'Nonaktif'}
                  </button>
                </div>
              ))
            )}
          </div>

        </div>

      </div>
    </div>
  );
};
