import React, { useState } from 'react';
import { 
  X, 
  BookOpen, 
  Zap, 
  AlertTriangle, 
  Cpu, 
  Radio, 
  CheckCircle2, 
  XCircle 
} from 'lucide-react';

interface PocketBookModalProps {
  onClose: () => void;
}

export const PocketBookModal: React.FC<PocketBookModalProps> = ({ onClose }) => {
  const [activeTab, setActiveTab] = useState<'led' | 'wiring' | 'sop' | 'faq'>('led');

  // LED Checker interactive state
  const [gsmState, setGsmState] = useState<'cepat' | 'lambat'>('lambat');
  const [mcuState, setMcuState] = useState<'berkedip' | 'mati'>('berkedip');
  const [acdcState, setAcdcState] = useState<'menyala' | 'mati'>('menyala');

  const isReady = gsmState === 'lambat' && mcuState === 'berkedip' && acdcState === 'menyala';

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#005DA6] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">BUKU SAKU DIGITAL S41</h2>
              <p className="text-[10px] text-blue-100">Panduan Lapangan & Diagnosa LED</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="flex border-b border-slate-200 bg-slate-50 shrink-0">
          <button
            onClick={() => setActiveTab('led')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'led' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500'
            }`}
          >
            DIAGNOSA LED
          </button>
          <button
            onClick={() => setActiveTab('wiring')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'wiring' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500'
            }`}
          >
            WIRING KABEL
          </button>
          <button
            onClick={() => setActiveTab('sop')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'sop' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500'
            }`}
          >
            SOP INSTALASI
          </button>
          <button
            onClick={() => setActiveTab('faq')}
            className={`flex-1 py-2 text-xs font-bold border-b-2 transition-all ${
              activeTab === 'faq' 
                ? 'border-blue-600 text-blue-600 bg-white' 
                : 'border-transparent text-slate-500'
            }`}
          >
            FAQ
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 space-y-4 flex-1 overflow-y-auto">

          {/* TAB 1: DIAGNOSA INDIKATOR LED */}
          {activeTab === 'led' && (
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 p-2.5 rounded-xl text-blue-900 text-xs">
                💡 <strong>Uji Mandiri:</strong> Pilih kondisi lampu pada fisik alat S41 Anda untuk mengecek apakah alat sudah siap menerima perintah SMS.
              </div>

              {/* Status Outcome Banner */}
              <div className={`p-4 rounded-2xl border-2 flex items-center gap-3 transition-all ${
                isReady 
                  ? 'bg-emerald-50 border-emerald-500 text-emerald-950' 
                  : 'bg-amber-50 border-amber-400 text-amber-950'
              }`}>
                {isReady ? (
                  <CheckCircle2 className="w-8 h-8 text-emerald-600 shrink-0" />
                ) : (
                  <XCircle className="w-8 h-8 text-amber-600 shrink-0" />
                )}
                <div>
                  <h3 className="font-black text-sm">
                    {isReady ? 'ALAT SIAP MENERIMA PERINTAH (READY)' : 'BELUM READY (MENUNGGU SINKRONISASI)'}
                  </h3>
                  <p className="text-[11px] opacity-90 mt-0.5">
                    {isReady 
                      ? 'Semua indikator modul sudah sinkron. Perintah PLNON / PLNOFF dapat dieksekusi normal.' 
                      : 'Pastikan sinyal GSM stabil dan kartu SIM terisi pulsa. Jangan kirim perintah sebelum lampu GSM berkedip lambat.'}
                  </p>
                </div>
              </div>

              {/* 1. GSM Indicator */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5 text-slate-800">
                    <Radio className="w-4 h-4 text-blue-600" />
                    1. LED MODUL GSM (SIM800L)
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    gsmState === 'lambat' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                  }`}>
                    {gsmState === 'lambat' ? 'Dapat Sinyal' : 'Mencari Sinyal'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => setGsmState('cepat')}
                    className={`p-2 rounded-lg border text-left ${
                      gsmState === 'cepat' ? 'bg-amber-500 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Kedip Cepat
                    <span className="block text-[10px] opacity-80">Mencari Sinyal (Belum Ready)</span>
                  </button>
                  <button
                    onClick={() => setGsmState('lambat')}
                    className={`p-2 rounded-lg border text-left ${
                      gsmState === 'lambat' ? 'bg-emerald-600 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Kedip Lambat
                    <span className="block text-[10px] opacity-80">Sinyal OK (Ready)</span>
                  </button>
                </div>
              </div>

              {/* 2. Microcontroller Indicator */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5 text-slate-800">
                    <Cpu className="w-4 h-4 text-blue-600" />
                    2. LED MICROCONTROLLER
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    mcuState === 'berkedip' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {mcuState === 'berkedip' ? 'Terhubung GSM' : 'Belum Terhubung'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => setMcuState('mati')}
                    className={`p-2 rounded-lg border text-left ${
                      mcuState === 'mati' ? 'bg-red-600 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Tidak Berkedip
                    <span className="block text-[10px] opacity-80">Belum Terhubung GSM</span>
                  </button>
                  <button
                    onClick={() => setMcuState('berkedip')}
                    className={`p-2 rounded-lg border text-left ${
                      mcuState === 'berkedip' ? 'bg-emerald-600 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Berkedip
                    <span className="block text-[10px] opacity-80">Terhubung GSM (Ready)</span>
                  </button>
                </div>
              </div>

              {/* 3. AC-DC Regulator */}
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs flex items-center gap-1.5 text-slate-800">
                    <Zap className="w-4 h-4 text-blue-600" />
                    3. REGULATOR AC TO DC (POWER)
                  </span>
                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    acdcState === 'menyala' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {acdcState === 'menyala' ? 'Tegangan ON' : 'Mati / Tidak Ada Arus'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <button
                    onClick={() => setAcdcState('mati')}
                    className={`p-2 rounded-lg border text-left ${
                      acdcState === 'mati' ? 'bg-red-600 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Mati (OFF)
                    <span className="block text-[10px] opacity-80">Tidak Dapat Tegangan</span>
                  </button>
                  <button
                    onClick={() => setAcdcState('menyala')}
                    className={`p-2 rounded-lg border text-left ${
                      acdcState === 'menyala' ? 'bg-emerald-600 text-white font-bold' : 'bg-white text-slate-700'
                    }`}
                  >
                    Menyala (ON)
                    <span className="block text-[10px] opacity-80">Power 220V Normal (Ready)</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: WIRING DIAGRAM (SKEMA KABEL) */}
          {activeTab === 'wiring' && (
            <div className="space-y-3">
              <div className="bg-slate-900 text-white p-3 rounded-2xl text-center space-y-3">
                <h4 className="text-xs font-black text-yellow-300">
                  DIAGRAM SAMBUNGAN SERI S41 (SLIDE 8 & 9)
                </h4>
                
                {/* Visual SVG diagram representation */}
                <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col items-center">
                  <div className="flex items-center justify-between w-full max-w-xs text-[11px] mb-2 font-mono">
                    <span className="bg-blue-900 px-2 py-0.5 rounded text-blue-200">DARI SR (TIANG)</span>
                    <span className="text-yellow-400">➔➔➔</span>
                    <span className="bg-emerald-900 px-2 py-0.5 rounded text-emerald-200">KE KWH METER</span>
                  </div>

                  <div className="w-full max-w-xs bg-slate-900 p-3 rounded-lg border border-slate-700 space-y-2 text-left font-mono text-[10px]">
                    <div className="flex items-center justify-between text-red-400">
                      <span>INPUT 1: FASA (SR)</span>
                      <span>➔ [ S41 RELAY 30A ] ➔</span>
                      <span>OUTPUT: FASA (KE METER)</span>
                    </div>
                    <div className="flex items-center justify-between text-cyan-400">
                      <span>INPUT 2: NETRAL (SR)</span>
                      <span>➔ [ S41 BOARD ] ➔</span>
                      <span>OUTPUT: NETRAL (KE METER)</span>
                    </div>
                  </div>
                </div>

                <div className="text-[11px] text-slate-300 text-left space-y-1">
                  <p>• <strong>Kapasitas Relay:</strong> Maksimal 30 A (Daya Pelanggan s/d 5500 VA).</p>
                  <p>• <strong>Konektor:</strong> Cable gland tipe PG-21 Nylon IP68 tahan air & cuaca.</p>
                  <p>• <strong>Posisi Pasang:</strong> Seri antara Saluran Rumah (SR) dengan KWh Meter, di dinding rumah atau langsung di tiang JTR/JTM.</p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SOP INSTALASI */}
          {activeTab === 'sop' && (
            <div className="space-y-3 text-xs">
              <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
                <h4 className="font-black text-slate-800">SOP PRA-INSTALASI:</h4>
                <ol className="list-decimal list-inside space-y-1 text-slate-600">
                  <li>Gunakan APD lengkap sesuai standard K3 PLN.</li>
                  <li>Siapkan kartu SIM GSM tipe <strong>Micro SIM</strong>.</li>
                  <li>Pastikan SIM Card <strong>sudah registrasi NIK/KK dan terisi pulsa</strong>.</li>
                  <li>Uji fungsi alat di kantor sebelum dibawa ke tiang pelanggan.</li>
                </ol>
              </div>

              <div className="bg-red-50 p-3 rounded-xl border border-red-200 space-y-2 text-red-950">
                <h4 className="font-black flex items-center gap-1.5 text-red-800">
                  <AlertTriangle className="w-4 h-4" />
                  PERINGATAN KRITIS PEMASANGAN:
                </h4>
                <ul className="list-disc list-inside space-y-1 text-[11px]">
                  <li><strong>MEMASANG SIM CARD HARUS DALAM KONDISI TIDAK BERTEGANGAN!</strong></li>
                  <li>Kuningan SIM card menghadap ke atas dan tanda potongan segitiga di luar hingga bunyi "klik".</li>
                  <li>Nomor admin wajib diawali dengan <code className="font-bold">+62</code>.</li>
                </ul>
              </div>
            </div>
          )}

          {/* TAB 4: FAQ */}
          {activeTab === 'faq' && (
            <div className="space-y-2 text-xs">
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900">Q: Apa itu S41?</p>
                <p className="text-slate-600 mt-0.5 text-[11px]">
                  S41 adalah Shuntrip For 1 Phase yaitu alat pemutus dan penyambung daya listrik jarak jauh berbasis SMS dengan kapasitas hingga 5500 VA (30A).
                </p>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900">Q: Jika listrik padam, apakah status relay hilang?</p>
                <p className="text-slate-600 mt-0.5 text-[11px]">
                  Tidak. S41 menyimpan status terakhir di memori internal non-volatile. Jika sebelumnya OFF, saat listrik menyala kembali relay tetap OFF.
                </p>
              </div>
              <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                <p className="font-bold text-slate-900">Q: Apakah kartu SIM bisa dipindah ke device lain?</p>
                <p className="text-slate-600 mt-0.5 text-[11px]">
                  Bisa. S41 tidak terikat pada satu kartu SIM tertentu. Pastikan operator yang digunakan memiliki sinyal stabil di lokasi pemasangan.
                </p>
              </div>
            </div>
          )}

        </div>

      </div>
    </div>
  );
};
