import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'id.pln.shuntrip.s41',
  appName: 'S41 Shuntrip Mobile',
  webDir: 'dist',
  server: {
    androidScheme: 'https'
  },
  plugins: {
    // Custom plugins or permissions can be declared here
  }
};

export default config;
