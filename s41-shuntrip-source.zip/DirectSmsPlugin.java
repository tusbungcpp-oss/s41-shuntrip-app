package id.pln.shuntrip.s41;

import android.telephony.SmsManager;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.JSObject;

@CapacitorPlugin(name = "DirectSmsPlugin")
public class DirectSmsPlugin extends Plugin {

    @PluginMethod
    public void sendSms(PluginCall call) {
        String phoneNumber = call.getString("phoneNumber");
        String message = call.getString("message");

        if (phoneNumber == null || message == null) {
            call.reject("Nomor tujuan dan isi pesan tidak boleh kosong");
            return;
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            JSObject ret = new JSObject();
            ret.put("success", true);
            ret.put("response", "SMS [" + message + "] berhasil diinjek langsung ke modem S41 " + phoneNumber);
            call.resolve(ret);
        } catch (Exception e) {
            call.reject("Gagal injek SMS native: " + e.getMessage());
        }
    }
}
