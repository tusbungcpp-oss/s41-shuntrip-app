import { getSupabaseClient, INITIAL_DEVICES, INITIAL_LOGS } from './supabase';
import type { S41Device, CommandLog, RelocationRecord } from '../types';

export const fetchDevices = async (): Promise<{ data: S41Device[]; isFromSupabase: boolean; error?: string }> => {
  const supabase = getSupabaseClient();
  if (!supabase) {
    return { data: INITIAL_DEVICES, isFromSupabase: false };
  }

  try {
    const { data, error } = await supabase
      .from('s41_devices')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Supabase fetch error (mungkin tabel belum dibuat):', error.message);
      return { data: INITIAL_DEVICES, isFromSupabase: false, error: error.message };
    }

    if (data && data.length > 0) {
      return { data: data as S41Device[], isFromSupabase: true };
    }

    return { data: INITIAL_DEVICES, isFromSupabase: true };
  } catch (err: any) {
    console.error('Network / Supabase error:', err);
    return { data: INITIAL_DEVICES, isFromSupabase: false, error: err.message };
  }
};

export const fetchLogs = async (): Promise<{ data: CommandLog[]; isFromSupabase: boolean }> => {
  const supabase = getSupabaseClient();
  if (!supabase) {
    return { data: INITIAL_LOGS, isFromSupabase: false };
  }

  try {
    const { data, error } = await supabase
      .from('s41_command_logs')
      .select('*')
      .order('timestamp', { ascending: false })
      .limit(50);

    if (error || !data) {
      return { data: INITIAL_LOGS, isFromSupabase: false };
    }

    return { data: data as CommandLog[], isFromSupabase: true };
  } catch {
    return { data: INITIAL_LOGS, isFromSupabase: false };
  }
};

export const upsertDeviceInSupabase = async (device: S41Device): Promise<boolean> => {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  try {
    const { error } = await supabase.from('s41_devices').upsert({
      id: device.id,
      idpel: device.idpel,
      nama_pelanggan: device.nama_pelanggan,
      tarif_daya: device.tarif_daya,
      nomor_meter: device.nomor_meter,
      nomor_sim: device.nomor_sim,
      masa_aktif_sim: device.masa_aktif_sim,
      tiang_jtr: device.tiang_jtr,
      alamat: device.alamat,
      status_relay: device.status_relay,
      status_tunggakan: device.status_tunggakan,
      signal_dbm: device.signal_dbm,
      uptime: device.uptime,
      unit_ulp: device.unit_ulp,
      unit_up3: device.unit_up3,
      unit_uid: device.unit_uid,
      updated_at: new Date().toISOString()
    });
    if (error) {
      console.warn('Upsert device failed in Supabase:', error.message);
      return false;
    }
    return true;
  } catch (e) {
    console.warn('Upsert device exception:', e);
    return false;
  }
};

export const saveLogToSupabase = async (log: CommandLog): Promise<boolean> => {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  try {
    const { error } = await supabase.from('s41_command_logs').insert({
      idpel: log.idpel,
      nama_pelanggan: log.nama_pelanggan,
      command: log.command,
      detail_arg: log.detail_arg || null,
      sender_name: log.sender_name,
      sender_role: log.sender_role,
      status: log.status,
      response_message: log.response_message || null,
      timestamp: log.timestamp
    });
    if (error) {
      console.warn('Save log failed in Supabase:', error.message);
      return false;
    }
    return true;
  } catch {
    return false;
  }
};

export const saveRelocationToSupabase = async (
  record: RelocationRecord,
  updatedDevice: S41Device
): Promise<boolean> => {
  const supabase = getSupabaseClient();
  if (!supabase) return false;

  try {
    // 1. Insert relocation history
    await supabase.from('s41_relocations').insert({
      nomor_sim: record.nomor_sim,
      idpel_asal: record.idpel_asal,
      nama_asal: record.nama_asal,
      idpel_tujuan: record.idpel_tujuan,
      nama_tujuan: record.nama_tujuan,
      alamat_tujuan: record.alamat_tujuan,
      tiang_tujuan: record.tiang_tujuan,
      alasan: record.alasan,
      ganti_sim: record.ganti_sim,
      nomor_sim_baru: record.nomor_sim_baru || null,
      relocated_by: record.relocated_by,
      timestamp: record.timestamp
    });

    // 2. Update device
    await upsertDeviceInSupabase(updatedDevice);
    return true;
  } catch (e) {
    console.warn('Relocation exception in Supabase:', e);
    return false;
  }
};
