# Aplikasi S41 Shuntrip Mobile (PLN Danantara)

Aplikasi PWA & Android (Capacitor) untuk kontrol pemutus & penyambung daya listrik jarak jauh berbasis SMS pada modul S41 Shuntrip 1 Fasa (30A).

## 🚀 Fitur Utama

1. **Autentikasi & Hak Akses Berbasis Peran (Role-Based Access):**
   - **Admin (Administrator Sistem / Kantor):**
     - Memiliki hak penuh (Full Access).
     - Pengaturan nomor Admin S41 (`SETADMIN`, `DELADMIN`, `LISTADMIN`, `RESETADMIN`, `PLNRESET`).
     - Fitur **Relokasi / Mutasi Alat ke IDPEL Baru** (lengkap dengan pencatatan audit trail aset).
     - Manajemen data pelanggan & inventaris unit.
   - **Kordinator (Operasional Lapangan):**
     - Monitoring status pelanggan/alat (Nyala / Padam / Menunggak).
     - Eksekusi harian langsung (`PLNON`, `PLNOFF`, `PLNSTATUS`).
     - Eksekusi Kolektif (Pemutusan/Penyambungan massal antrean).
     - Terproteksi dari fitur reset alat & admin alat.

2. **Injeksi SMS Langsung (Direct SMS Injection):**
   - Siap dibungkus menjadi APK Android menggunakan Capacitor dengan hak akses sistem `android.permission.SEND_SMS` dan `RECEIVE_SMS`.
   - Dilengkapi dual-mode engine: Injeksi langsung di latar belakang atau buka aplikasi SMS HP.
   - Realistis GSM tower simulator saat uji coba di browser (memvalidasi format `+62` dan menghasilkan balasan resmi S41).

3. **Eksekusi Kolektif (Batch Execution):**
   - Memilih 5, 10, atau puluhan pelanggan menunggak sekaligus.
   - Antrean pengiriman berurutan dengan progress bar persentase live.

4. **Relokasi / Pindah Alat S41 ke IDPEL Lain:**
   - Formulir mutasi alat dari IDPEL asal ke IDPEL tujuan.
   - Opsi penggantian kartu SIM Micro SIM atau tetap menggunakan kartu lama.
   - Catatan alasan mutasi aset untuk pelaporan ULP / UP3.

5. **Buku Saku Digital & Diagnosa LED Interaktif:**
   - Uji mandiri kedipan lampu LED Modul GSM (SIM800L), Microcontroller, dan Regulator AC-DC.
   - Diagram kabel seri SR (Saluran Rumah) ke KWh Meter.
   - SOP pemasangan dan peringatan keselamatan K3 PLN.

6. **Integrasi Supabase:**
   - Tersedia generator skema SQL siap salin di menu aplikasi untuk membuat tabel `pln_units`, `s41_devices`, `s41_relocations`, dan `s41_command_logs`.

---

## 📱 Menjalankan Aplikasi

Aplikasi saat ini aktif berjalan pada:
- **Lokal (Komputer):** `http://localhost:5173/`
- **Jaringan Wi-Fi (Buka di HP):** `http://192.168.1.19:5173/`

### Membangun File APK Android:
```bash
# 1. Build aset web
npm run build

# 2. Tambahkan platform Android
npx cap add android

# 3. Buka Android Studio untuk build APK
npx cap open android
```
