import React, { useState } from 'react';
import { 
  X, 
  History, 
  Search, 
  Trash2 
} from 'lucide-react';
import type { CommandLog, UserProfile } from '../types';

interface LogAuditModalProps {
  logs: CommandLog[];
  currentUser: UserProfile;
  onClose: () => void;
  onClearLogs?: () => void;
}

export const LogAuditModal: React.FC<LogAuditModalProps> = ({
  logs,
  currentUser,
  onClose,
  onClearLogs,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCmd, setFilterCmd] = useState<string>('ALL');

  const filteredLogs = logs.filter((l) => {
    const matchesSearch = 
      l.idpel.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.nama_pelanggan.toLowerCase().includes(searchTerm.toLowerCase()) ||
      l.sender_name.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCmd = filterCmd === 'ALL' || l.command === filterCmd;

    return matchesSearch && matchesCmd;
  });

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-lg bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-[#003664] text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/10 flex items-center justify-center">
              <History className="w-5 h-5 text-yellow-300" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">LOG AUDIT & RIWAYAT SMS</h2>
              <p className="text-[10px] text-blue-200">Catatan Aktivitas Eksekusi S41</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter & Search Bar */}
        <div className="p-3 bg-slate-50 border-b border-slate-200 space-y-2">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400 pointer-events-none" />
            <input
              type="text"
              placeholder="Cari IDPEL, Nama, atau Petugas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div className="flex gap-1 overflow-x-auto pb-1 text-[11px]">
            {['ALL', 'PLNOFF', 'PLNON', 'PLNSTATUS', 'SETADMIN'].map((cmd) => (
              <button
                key={cmd}
                onClick={() => setFilterCmd(cmd)}
                className={`px-2.5 py-1 rounded-lg font-bold shrink-0 transition-all ${
                  filterCmd === cmd
                    ? 'bg-blue-600 text-white shadow-xs'
                    : 'bg-white text-slate-600 border border-slate-200'
                }`}
              >
                {cmd}
              </button>
            ))}
          </div>
        </div>

        {/* Log List */}
        <div className="p-3 overflow-y-auto space-y-2 flex-1">
          {filteredLogs.length === 0 ? (
            <div className="text-center py-10 text-slate-400 text-xs">
              Tidak ada catatan log ditemukan.
            </div>
          ) : (
            filteredLogs.map((log) => (
              <div 
                key={log.id}
                className="p-3 rounded-xl border border-slate-200 bg-white shadow-2xs space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <span className={`font-mono font-black px-1.5 py-0.5 rounded text-[10px] ${
                      log.command === 'PLNOFF' 
                        ? 'bg-red-100 text-red-800' 
                        : log.command === 'PLNON'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}>
                      {log.command}
                    </span>
                    <span className="font-bold text-slate-900">{log.nama_pelanggan}</span>
                  </div>

                  <span className="text-[10px] text-slate-400 font-mono">
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                  </span>
                </div>

                <div className="flex justify-between text-[11px] text-slate-500 font-mono">
                  <span>IDPEL: {log.idpel}</span>
                  <span className="flex items-center gap-1 text-slate-700">
                    Petugas: <strong>{log.sender_name}</strong>
                  </span>
                </div>

                {log.response_message && (
                  <div className="mt-1 p-2 bg-slate-900 text-emerald-400 font-mono text-[10px] rounded-lg">
                    {log.response_message}
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-3 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs">
          <span className="text-slate-500 text-[11px]">
            Total: <strong>{filteredLogs.length}</strong> log tersimpan
          </span>

          {currentUser.role === 'admin' && onClearLogs && (
            <button
              onClick={() => {
                if (confirm('Yakin ingin membersihkan riwayat log?')) {
                  onClearLogs();
                }
              }}
              className="flex items-center gap-1 text-red-600 hover:text-red-700 font-bold text-[11px]"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Bersihkan Log</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
};
