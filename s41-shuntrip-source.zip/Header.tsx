import React from 'react';
import { 
  ShieldCheck, 
  BookOpen, 
  History, 
  Database, 
  LogOut, 
  Radio,
  Users
} from 'lucide-react';
import type { UserProfile } from '../types';

interface HeaderProps {
  user: UserProfile;
  onLogout: () => void;
  onOpenPocketBook: () => void;
  onOpenLogs: () => void;
  onOpenConfig: () => void;
  onOpenUsers?: () => void;
  isSupabaseConnected: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  onLogout,
  onOpenPocketBook,
  onOpenLogs,
  onOpenConfig,
  onOpenUsers,
  isSupabaseConnected,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-[#005DA6] text-white shadow-md">
      {/* Top Bar */}
      <div className="max-w-md mx-auto px-4 py-2.5 flex items-center justify-between">
        {/* Brand */}
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 rounded-full bg-white p-1 flex items-center justify-center shadow-inner">
            <img src="/logo-s41.svg" alt="S41" className="w-full h-full object-contain" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-black tracking-tight text-base">S41 SHUNTRIP</span>
              <span className="bg-[#FED400] text-[#003664] text-[10px] font-extrabold px-1.5 py-0.2 rounded uppercase">
                1 Phase
              </span>
            </div>
            <p className="text-[10px] text-blue-100 font-medium tracking-wide">
              PLN Danantara Indonesia • 30A
            </p>
          </div>
        </div>

        {/* Quick Nav Tools */}
        <div className="flex items-center gap-1">
          {user.role === 'admin' && onOpenUsers && (
            <button
              onClick={onOpenUsers}
              title="Manajemen Pengguna (Admin)"
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-amber-300"
            >
              <Users className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onOpenPocketBook}
            title="Buku Saku & Panduan LED"
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-yellow-300"
          >
            <BookOpen className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenLogs}
            title="Log Riwayat SMS"
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 active:scale-95 transition-all text-white"
          >
            <History className="w-4 h-4" />
          </button>
          <button
            onClick={onOpenConfig}
            title="Koneksi Supabase"
            className={`p-1.5 rounded-lg transition-all active:scale-95 ${
              isSupabaseConnected 
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/40' 
                : 'bg-white/10 text-slate-300'
            }`}
          >
            <Database className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* User Status Bar */}
      <div className="bg-[#004882] px-4 py-1.5 text-xs border-t border-blue-400/20">
        <div className="max-w-md mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2 truncate">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="font-semibold truncate text-[11px]">{user.nama}</span>
            <span className="text-blue-200 text-[10px] hidden sm:inline">({user.nip})</span>
            
            {/* Role Badge */}
            {user.role === 'admin' ? (
              <span className="bg-amber-400 text-slate-900 font-black text-[9px] px-1.5 py-0.5 rounded flex items-center gap-0.5">
                <ShieldCheck className="w-2.5 h-2.5" />
                ADMIN (Sistem)
              </span>
            ) : (
              <span className="bg-emerald-400 text-slate-950 font-black text-[9px] px-1.5 py-0.5 rounded flex items-center gap-0.5">
                <Radio className="w-2.5 h-2.5" />
                KORDINATOR (Lapangan)
              </span>
            )}
          </div>

          <button
            onClick={onLogout}
            title="Keluar"
            className="flex items-center gap-1 text-[11px] text-blue-200 hover:text-white hover:bg-white/10 px-1.5 py-0.5 rounded transition-all"
          >
            <LogOut className="w-3 h-3 text-red-300" />
            <span className="text-[10px]">Keluar</span>
          </button>
        </div>
      </div>
    </header>
  );
};
