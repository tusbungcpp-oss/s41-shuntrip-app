export type UserRole = 'admin' | 'kordinator';

export interface UserProfile {
  id: string;
  nip: string;
  nama: string;
  role: UserRole;
  unit_name: string;
  phone: string;
}

export type DeviceStatus = 'ON' | 'OFF' | 'UNKNOWN';
export type PaymentStatus = 'LUNAS' | 'MENUNGGAK';

export interface S41Device {
  id: string;
  idpel: string;
  nama_pelanggan: string;
  tarif_daya: string;
  nomor_meter: string;
  nomor_sim: string;
  masa_aktif_sim: string;
  tiang_jtr: string;
  alamat: string;
  status_relay: DeviceStatus;
  status_tunggakan: PaymentStatus;
  signal_dbm: number;
  uptime: string;
  unit_ulp: string;
  unit_up3: string;
  unit_uid: string;
  foto_instalasi?: string;
  created_at: string;
  updated_at: string;
}

export interface CommandLog {
  id: string;
  device_id: string;
  idpel: string;
  nama_pelanggan: string;
  command: 'PLNON' | 'PLNOFF' | 'PLNSTATUS' | 'PLNRESET' | 'SETADMIN' | 'DELADMIN' | 'RESETADMIN' | 'LISTADMIN';
  detail_arg?: string;
  sender_name: string;
  sender_role: UserRole;
  status: 'SENT' | 'SUCCESS' | 'FAILED';
  response_message?: string;
  timestamp: string;
}

export interface RelocationRecord {
  id: string;
  device_id: string;
  nomor_sim: string;
  idpel_asal: string;
  nama_asal: string;
  idpel_tujuan: string;
  nama_tujuan: string;
  alamat_tujuan: string;
  tiang_tujuan: string;
  alasan: string;
  ganti_sim: boolean;
  nomor_sim_baru?: string;
  relocated_by: string;
  timestamp: string;
}
