import React, { useState } from 'react';
import { 
  X, 
  ArrowRightLeft, 
  CheckCircle2
} from 'lucide-react';
import type { S41Device, RelocationRecord, UserProfile } from '../types';
import { formatIndonesianPhone } from '../lib/smsEngine';

interface RelocationModalProps {
  device: S41Device;
  currentUser: UserProfile;
  onClose: () => void;
  onConfirmRelocation: (updatedDevice: S41Device, record: RelocationRecord) => void;
}

export const RelocationModal: React.FC<RelocationModalProps> = ({
  device,
  currentUser,
  onClose,
  onConfirmRelocation,
}) => {
  // New target customer inputs
  const [newIdpel, setNewIdpel] = useState('');
  const [newNama, setNewNama] = useState('');
  const [newTarifDaya, setNewTarifDaya] = useState('R1/900 VA');
  const [newAlamat, setNewAlamat] = useState('');
  const [newTiang, setNewTiang] = useState('');
  const [reason, setReason] = useState('Pelanggan lama sudah tertib/lunas, alat dialihkan ke pelanggan baru yang menunggak');
  
  // SIM Card choice
  const [changeSim, setChangeSim] = useState(false);
  const [newSimNumber, setNewSimNumber] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newIdpel || !newNama) {
      alert('Harap isi ID Pelanggan dan Nama Pelanggan tujuan.');
      return;
    }

    if (changeSim && !newSimNumber) {
      alert('Harap masukkan nomor SIM card baru.');
      return;
    }

    const finalSim = changeSim ? formatIndonesianPhone(newSimNumber) : device.nomor_sim;

    const record: RelocationRecord = {
      id: 'reloc-' + Date.now(),
      device_id: device.id,
      nomor_sim: finalSim,
      idpel_asal: device.idpel,
      nama_asal: device.nama_pelanggan,
      idpel_tujuan: newIdpel,
      nama_tujuan: newNama,
      alamat_tujuan: newAlamat,
      tiang_tujuan: newTiang,
      alasan: reason,
      ganti_sim: changeSim,
      nomor_sim_baru: changeSim ? finalSim : undefined,
      relocated_by: `${currentUser.nama} (${currentUser.nip})`,
      timestamp: new Date().toISOString()
    };

    const updatedDevice: S41Device = {
      ...device,
      idpel: newIdpel,
      nama_pelanggan: newNama,
      tarif_daya: newTarifDaya,
      alamat: newAlamat || device.alamat,
      tiang_jtr: newTiang || device.tiang_jtr,
      nomor_sim: finalSim,
      status_relay: 'ON', // reset relay to default ON upon installation
      status_tunggakan: 'MENUNGGAK',
      updated_at: new Date().toISOString()
    };

    onConfirmRelocation(updatedDevice, record);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4">
      <div className="w-full max-w-md bg-white rounded-t-3xl sm:rounded-2xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden animate-in slide-in-from-bottom duration-200">
        
        {/* Header */}
        <div className="bg-amber-600 text-white p-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
              <ArrowRightLeft className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-sm font-black tracking-tight">RELOKASI ALAT S41</h2>
              <p className="text-[10px] text-amber-100">Mutasi Aset ke IDPEL Baru</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-1 rounded-full bg-white/10 hover:bg-white/20 text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4 flex-1 overflow-y-auto">

          {/* Current Source Device Info */}
          <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
              PELANGGAN ASAL (LAMA):
            </span>
            <div className="flex justify-between font-bold text-slate-800">
              <span>{device.nama_pelanggan}</span>
              <span className="font-mono text-blue-700">{device.idpel}</span>
            </div>
            <div className="flex justify-between text-[11px] text-slate-500 mt-1">
              <span>SIM Alat Saat Ini:</span>
              <span className="font-mono">{device.nomor_sim}</span>
            </div>
          </div>

          {/* Target Customer Info */}
          <div className="space-y-3">
            <span className="text-xs font-black text-slate-800 block">
              DATA PELANGGAN BARU (TUJUAN):
            </span>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                ID PELANGGAN BARU (IDPEL) *
              </label>
              <input
                type="text"
                required
                value={newIdpel}
                onChange={(e) => setNewIdpel(e.target.value)}
                placeholder="Contoh: 541200998877"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                NAMA PELANGGAN BARU *
              </label>
              <input
                type="text"
                required
                value={newNama}
                onChange={(e) => setNewNama(e.target.value)}
                placeholder="Contoh: Irwan / Toko Berkah"
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  TARIF / DAYA
                </label>
                <select
                  value={newTarifDaya}
                  onChange={(e) => setNewTarifDaya(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
                >
                  <option value="R1/450 VA">R1 / 450 VA</option>
                  <option value="R1/900 VA">R1 / 900 VA</option>
                  <option value="R1/1300 VA">R1 / 1300 VA</option>
                  <option value="R1/2200 VA">R1 / 2200 VA</option>
                  <option value="B1/5500 VA">B1 / 5500 VA (Max)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1">
                  NO. TIANG JTR
                </label>
                <input
                  type="text"
                  value={newTiang}
                  onChange={(e) => setNewTiang(e.target.value)}
                  placeholder="TR-PTK-099"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                ALAMAT BARU
              </label>
              <input
                type="text"
                value={newAlamat}
                onChange={(e) => setNewAlamat(e.target.value)}
                placeholder="Nama jalan / desa / kecamatan..."
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            {/* SIM Card option */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 space-y-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-800">
                <input
                  type="checkbox"
                  checked={changeSim}
                  onChange={(e) => setChangeSim(e.target.checked)}
                  className="w-4 h-4 text-amber-600 rounded"
                />
                <span>Ganti Kartu SIM S41 dengan nomor baru?</span>
              </label>

              {changeSim && (
                <div className="pt-1">
                  <label className="block text-[10px] font-semibold text-slate-600 mb-1">
                    NOMOR SIM CARD BARU (MICRO SIM) *
                  </label>
                  <input
                    type="text"
                    required={changeSim}
                    value={newSimNumber}
                    onChange={(e) => setNewSimNumber(e.target.value)}
                    placeholder="08123456789"
                    className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 font-mono focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  />
                  <p className="text-[10px] text-slate-500 mt-1">
                    *Pastikan kartu SIM sudah diaktivasi dan terisi pulsa sesuai SOP.
                  </p>
                </div>
              )}
            </div>

            {/* Reason */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 mb-1">
                ALASAN MUTASI / CATATAN LAPORAN
              </label>
              <textarea
                rows={2}
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-amber-500 focus:outline-none"
              ></textarea>
            </div>
          </div>

          {/* Submit Button */}
          <div className="pt-2">
            <button
              type="submit"
              className="w-full py-3 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-amber-600/20 active:scale-[0.99] transition-all"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>SIMPAN RELOKASI ASET S41</span>
            </button>
          </div>
        </form>

      </div>
    </div>
  );
};
